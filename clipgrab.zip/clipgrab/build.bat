@echo off
cd /d "%~dp0"
title ClipGrab Builder

echo ============================================
echo  ClipGrab Builder
echo ============================================
echo.
echo This will install packages and build ClipGrab.exe
echo Takes about 3-5 minutes total.
echo.
pause

:: Check Python
echo [1/6] Checking Python...
python --version >nul 2>&1
if errorlevel 1 (
    echo.
    echo ERROR: Python not found!
    echo Install from https://python.org
    echo IMPORTANT: Tick "Add Python to PATH" during install.
    echo.
    pause
    exit /b 1
)
python --version
echo OK.
echo.

:: Upgrade pip
echo [2/6] Updating pip...
python -m pip install --upgrade pip --quiet
echo OK.
echo.

:: Install dependencies
echo [3/6] Installing Flask and PyInstaller...
python -m pip install flask pyinstaller --quiet
if errorlevel 1 (
    echo ERROR: pip install failed. Check internet connection.
    pause
    exit /b 1
)
echo OK.
echo.

:: Download yt-dlp.exe
echo [4/6] Downloading yt-dlp.exe...
if exist yt-dlp.exe (
    echo Already present, skipping.
) else (
    curl -L "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe" -o yt-dlp.exe --progress-bar
    if errorlevel 1 (
        echo ERROR: Could not download yt-dlp.exe.
        pause
        exit /b 1
    )
)
echo OK.
echo.

:: Download and extract ffmpeg
echo [5/6] Downloading ffmpeg (one-time, ~80MB)...
if exist ffmpeg\bin\ffmpeg.exe (
    echo Already present, skipping.
) else (
    curl -L "https://github.com/yt-dlp/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip" -o ffmpeg.zip --progress-bar
    if errorlevel 1 (
        echo WARNING: Could not download ffmpeg. Videos may save as separate files.
        goto BUILD
    )
    echo Extracting ffmpeg...
    powershell -Command "Expand-Archive -Path 'ffmpeg.zip' -DestinationPath 'ffmpeg_tmp' -Force"
    for /d %%i in (ffmpeg_tmp\ffmpeg-*) do move "%%i" ffmpeg >nul 2>&1
    rmdir /s /q ffmpeg_tmp 2>nul
    del ffmpeg.zip 2>nul
)
echo OK.
echo.

:BUILD
:: Clean old builds
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist ClipGrab.spec del ClipGrab.spec

:: Build exe — bundle yt-dlp and ffmpeg binaries inside
echo [6/6] Building ClipGrab.exe...
echo.
python -m PyInstaller ^
    --onefile ^
    --noconsole ^
    --name ClipGrab ^
    --add-data "templates;templates" ^
    --add-binary "yt-dlp.exe;." ^
    --add-binary "ffmpeg\bin\ffmpeg.exe;ffmpeg\bin" ^
    --add-binary "ffmpeg\bin\ffprobe.exe;ffmpeg\bin" ^
    server.py

if errorlevel 1 (
    echo.
    echo ERROR: Build failed.
    pause
    exit /b 1
)

copy /y dist\ClipGrab.exe ClipGrab.exe >nul

echo.
echo ============================================
echo  BUILD SUCCESSFUL!
echo ============================================
echo.
echo  ClipGrab.exe is ready in this folder.
echo  Double-click it to launch.
echo  Browser opens automatically.
echo  ffmpeg is bundled in — videos merge correctly.
echo ============================================
echo.
pause
