# ClipGrab — Setup Guide

## STEP 1: Install Python
Download from https://python.org
During install → tick "Add Python to PATH"  ← important!

---

## STEP 2: Choose how to run

### Quickest — double-click run.bat
- Opens your browser automatically
- Keep the black terminal window open while using the app
- Close the terminal to stop

### Or build a standalone ClipGrab.exe — double-click build.bat
- Takes 2-3 minutes to compile
- ClipGrab.exe appears in this folder when done
- Double-click it anytime — no Python needed after

---

## DO NOT double-click yt-dlp.exe — it's a command-line tool used internally by the app.

---

## How to use the app

- Single video: Paste URL → Analyze → Add to queue → Download all
- Batch: Drop your vid.txt (one URL per line) → Import all → Download all
- Custom folder: Click the folder icon → type your path → Open folder to see files

## Supported sites
YouTube, Vimeo, Twitter/X, TikTok, Instagram, Facebook, SoundCloud, Dailymotion + 1000 more.

## For best quality (4K/1080p)
Install ffmpeg from https://ffmpeg.org and add to PATH — needed to merge video+audio streams.
