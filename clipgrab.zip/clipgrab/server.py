import os
import sys
import json
import threading
import webbrowser
import subprocess
import re
from flask import Flask, request, jsonify, send_from_directory

app = Flask(__name__, static_folder='static', template_folder='templates')

jobs = {}

def get_base_dir():
    if getattr(sys, 'frozen', False):
        return sys._MEIPASS
    return os.path.dirname(os.path.abspath(__file__))

def get_ytdlp():
    base = get_base_dir()
    # When frozen (exe), look in bundled location
    exe = os.path.join(base, 'yt-dlp.exe')
    if os.path.exists(exe):
        return exe
    # When running as script, look next to server.py
    local = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'yt-dlp.exe')
    if os.path.exists(local):
        return local
    return 'yt-dlp'

def get_ffmpeg():
    base = get_base_dir()
    script_dir = os.path.dirname(os.path.abspath(__file__))
    candidates = [
        os.path.join(base, 'ffmpeg', 'bin', 'ffmpeg.exe'),       # bundled in exe
        os.path.join(script_dir, 'ffmpeg', 'bin', 'ffmpeg.exe'), # next to script
    ]
    for p in candidates:
        if os.path.exists(p):
            ffmpeg_bin = os.path.dirname(p)
            # Add to PATH so yt-dlp can find ffprobe too
            os.environ['PATH'] = ffmpeg_bin + os.pathsep + os.environ.get('PATH', '')
            return p
    return 'ffmpeg'  # fall back to system PATH

# Resolve ffmpeg once at startup
FFMPEG_PATH = get_ffmpeg()

@app.route('/')
def index():
    return send_from_directory('templates', 'index.html')

@app.route('/static/<path:path>')
def static_files(path):
    return send_from_directory('static', path)

@app.route('/api/analyze', methods=['POST'])
def analyze():
    data = request.json
    url = data.get('url', '').strip()
    if not url:
        return jsonify({'error': 'No URL provided'}), 400
    try:
        ytdlp = get_ytdlp()
        result = subprocess.run(
            [ytdlp, '--dump-json', '--no-playlist', url],
            capture_output=True, text=True, timeout=30
        )
        if result.returncode != 0:
            return jsonify({'error': 'Could not fetch video info. Check the URL.'}), 400
        info = json.loads(result.stdout)
        formats = info.get('formats', [])
        resolutions = sorted(set(
            f"{f['height']}p" for f in formats
            if f.get('height') and f.get('vcodec') != 'none'
        ), key=lambda x: int(x[:-1]), reverse=True)
        return jsonify({
            'title': info.get('title', 'Unknown'),
            'uploader': info.get('uploader', ''),
            'duration': format_duration(info.get('duration', 0)),
            'thumbnail': info.get('thumbnail', ''),
            'resolutions': resolutions or ['Best available'],
            'extractor': info.get('extractor_key', 'Web'),
        })
    except subprocess.TimeoutExpired:
        return jsonify({'error': 'Timed out. Check your internet connection.'}), 408
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/download', methods=['POST'])
def download():
    data = request.json
    url = data.get('url', '').strip()
    fmt = data.get('format', 'mp4')
    quality = data.get('quality', 'best')
    folder = data.get('folder', os.path.expanduser('~/Downloads'))
    job_id = data.get('job_id')

    if not url or not job_id:
        return jsonify({'error': 'Missing url or job_id'}), 400

    os.makedirs(folder, exist_ok=True)
    jobs[job_id] = {'status': 'downloading', 'progress': 0, 'speed': '', 'error': None}

    thread = threading.Thread(target=run_download, args=(job_id, url, fmt, quality, folder))
    thread.daemon = True
    thread.start()

    return jsonify({'ok': True, 'job_id': job_id})

def run_download(job_id, url, fmt, quality, folder):
    ytdlp = get_ytdlp()
    out_tmpl = os.path.join(folder, '%(title)s.%(ext)s')

    # Base flags used for all downloads
    base_flags = [
        '--ffmpeg-location', os.path.dirname(FFMPEG_PATH),
        '--no-playlist',
        '--newline',
        '-o', out_tmpl,
    ]

    if fmt in ('mp3', 'm4a', 'ogg'):
        cmd = [ytdlp] + base_flags + [
            '--extract-audio',
            '--audio-format', fmt,
            '--audio-quality', '0',
            url
        ]
    else:
        height = quality.replace('p', '').split(' ')[0] if 'p' in quality else 'best'
        if height.isdigit():
            fmt_str = f'bestvideo[height<={height}][ext=mp4]+bestaudio[ext=m4a]/bestvideo[height<={height}]+bestaudio/best[height<={height}]'
        else:
            fmt_str = 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/bestvideo+bestaudio/best'
        cmd = [ytdlp] + base_flags + [
            '-f', fmt_str,
            '--merge-output-format', fmt,
            url
        ]

    try:
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == 'win32' else 0
        )
        for line in proc.stdout:
            line = line.strip()
            m = re.search(r'\[download\]\s+([\d\.]+)%.*?at\s+([\d\.\w/]+)', line)
            if m:
                jobs[job_id]['progress'] = float(m.group(1))
                jobs[job_id]['speed'] = m.group(2)
        proc.wait()
        if proc.returncode == 0:
            jobs[job_id]['status'] = 'done'
            jobs[job_id]['progress'] = 100
        else:
            jobs[job_id]['status'] = 'error'
            jobs[job_id]['error'] = 'Download failed'
    except Exception as e:
        jobs[job_id]['status'] = 'error'
        jobs[job_id]['error'] = str(e)

@app.route('/api/progress/<job_id>')
def progress(job_id):
    job = jobs.get(job_id)
    if not job:
        return jsonify({'error': 'Job not found'}), 404
    return jsonify(job)

@app.route('/api/open-folder', methods=['POST'])
def open_folder():
    data = request.json
    folder = data.get('folder', os.path.expanduser('~/Downloads'))
    folder = os.path.expanduser(folder)
    try:
        if sys.platform == 'win32':
            os.startfile(folder)
        elif sys.platform == 'darwin':
            subprocess.Popen(['open', folder])
        else:
            subprocess.Popen(['xdg-open', folder])
        return jsonify({'ok': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

def format_duration(seconds):
    if not seconds:
        return 'Live'
    m, s = divmod(int(seconds), 60)
    h, m = divmod(m, 60)
    if h:
        return f'{h}:{m:02d}:{s:02d}'
    return f'{m}:{s:02d}'

def open_browser():
    import time
    time.sleep(1.2)
    webbrowser.open('http://127.0.0.1:5000')

if __name__ == '__main__':
    t = threading.Thread(target=open_browser)
    t.daemon = True
    t.start()
    app.run(host='127.0.0.1', port=5000, debug=False)
