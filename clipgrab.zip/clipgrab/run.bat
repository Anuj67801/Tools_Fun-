@echo off
cd /d "%~dp0"
title ClipGrab
echo.
echo ============================================
echo  ClipGrab - Starting...
echo ============================================
echo.

:: Check Python
echo Checking Python...
python --version
if errorlevel 1 (
    echo.
    echo ERROR: Python not found or not in PATH.
    echo.
    echo Fix: Uninstall Python and reinstall from https://python.org
    echo      On the FIRST screen of the installer, tick:
    echo      "Add Python to PATH"  ^<--- this is the important one
    echo.
    pause
    exit /b 1
)
echo.

:: Install/update packages
echo Installing required packages (flask, yt-dlp)...
python -m pip install flask yt-dlp --quiet
if errorlevel 1 (
    echo ERROR: pip failed. Try running this window as Administrator.
    pause
    exit /b 1
)
echo Done.
echo.

:: Download yt-dlp.exe if missing
if not exist yt-dlp.exe (
    echo Downloading yt-dlp.exe...
    curl -L "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe" -o yt-dlp.exe
    if errorlevel 1 (
        echo ERROR: Could not download yt-dlp.exe. Check internet.
        pause
        exit /b 1
    )
    echo Done.
    echo.
)

:: Download ffmpeg if missing
if not exist ffmpeg\bin\ffmpeg.exe (
    echo Downloading ffmpeg - one time only, about 80MB...
    curl -L "https://github.com/yt-dlp/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip" -o ffmpeg.zip
    if errorlevel 1 (
        echo WARNING: ffmpeg download failed. Videos may save as separate files.
        goto LAUNCH
    )
    echo Extracting ffmpeg...
    powershell -Command "Expand-Archive -Path 'ffmpeg.zip' -DestinationPath 'ffmpeg_tmp' -Force"
    for /d %%i in (ffmpeg_tmp\ffmpeg-*) do move "%%i" ffmpeg >nul 2>&1
    rmdir /s /q ffmpeg_tmp 2>nul
    del ffmpeg.zip 2>nul
    echo ffmpeg ready.
    echo.
)

:: Add ffmpeg to PATH for this session
set "PATH=%~dp0ffmpeg\bin;%PATH%"

:LAUNCH
echo ============================================
echo  Launching ClipGrab...
echo  Browser will open at http://127.0.0.1:5000
echo  Keep this window open while using the app.
echo  Press Ctrl+C or close window to stop.
echo ============================================
echo.
python server.py
if errorlevel 1 (
    echo.
    echo ERROR: server.py crashed. Details above.
    pause
)
