"""
PDFForge Pro - Full-featured PDF Tool Suite
Run: python main.py
"""

import sys
import os
import json
import shutil
import tempfile
import threading
from pathlib import Path
from datetime import datetime

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QFileDialog, QListWidget, QListWidgetItem,
    QStackedWidget, QScrollArea, QGridLayout, QFrame, QLineEdit,
    QSpinBox, QComboBox, QCheckBox, QProgressBar, QTextEdit,
    QSplitter, QGroupBox, QSlider, QTabWidget, QMessageBox,
    QDialog, QDialogButtonBox, QInputDialog, QSizePolicy,
    QAbstractItemView, QToolButton
)
from PyQt6.QtCore import (
    Qt, QThread, pyqtSignal, QMimeData, QSize, QPropertyAnimation,
    QEasingCurve, QTimer, QPoint
)
from PyQt6.QtGui import (
    QFont, QColor, QPalette, QIcon, QPixmap, QPainter,
    QDragEnterEvent, QDropEvent, QFontDatabase, QCursor
)

# ── Themes ────────────────────────────────────────────────────────────────────

LIGHT_THEME = """
QMainWindow, QWidget#central { background: #F0F2F5; }
QWidget#sidebar { background: #FFFFFF; border-right: 1px solid #E5E7EB; }
QWidget#topbar { background: #FFFFFF; border-bottom: 1px solid #E5E7EB; }
QWidget#statusbar_widget { background: #FFFFFF; border-top: 1px solid #E5E7EB; }
QWidget#content_area { background: #F0F2F5; }
QLabel#app_title { color: #111827; font-size: 15px; font-weight: bold; }
QLabel#nav_section_label { color: #9CA3AF; font-size: 10px; }
QPushButton#nav_btn { background: transparent; border: none; border-radius: 8px;
    color: #6B7280; text-align: left; padding: 8px 12px; font-size: 13px; }
QPushButton#nav_btn:hover { background: #F3F4F6; color: #111827; }
QPushButton#nav_btn[active="true"] { background: #FEE2E2; color: #DC2626; font-weight: bold; }
QPushButton#open_btn { background: #DC2626; color: white; border: none;
    border-radius: 8px; padding: 8px 18px; font-size: 13px; font-weight: bold; }
QPushButton#open_btn:hover { background: #B91C1C; }
QWidget#tool_card { background: #FFFFFF; border: 1px solid #E5E7EB;
    border-radius: 10px; }
QWidget#tool_card:hover { border: 1px solid #DC2626; }
QLabel#tool_name { color: #111827; font-size: 12px; font-weight: bold; }
QLabel#tool_desc { color: #6B7280; font-size: 10px; }
QLabel#section_title { color: #6B7280; font-size: 11px; font-weight: bold; }
QLabel#page_title { color: #111827; font-size: 17px; font-weight: bold; }
QLabel#page_subtitle { color: #6B7280; font-size: 12px; }
QLabel#status_text { color: #6B7280; font-size: 11px; }
QPushButton#action_btn { background: #DC2626; color: white; border: none;
    border-radius: 8px; padding: 10px 20px; font-size: 13px; font-weight: bold; }
QPushButton#action_btn:hover { background: #B91C1C; }
QPushButton#action_btn:disabled { background: #D1D5DB; color: #9CA3AF; }
QPushButton#secondary_btn { background: #F3F4F6; color: #374151; border: 1px solid #E5E7EB;
    border-radius: 8px; padding: 8px 16px; font-size: 13px; }
QPushButton#secondary_btn:hover { background: #E5E7EB; }
QListWidget { background: #FFFFFF; border: 1px solid #E5E7EB; border-radius: 8px;
    color: #374151; font-size: 12px; }
QListWidget::item { padding: 6px 10px; border-bottom: 1px solid #F3F4F6; }
QListWidget::item:selected { background: #FEE2E2; color: #DC2626; }
QLineEdit, QSpinBox, QComboBox { background: #FFFFFF; border: 1px solid #D1D5DB;
    border-radius: 6px; padding: 6px 10px; color: #374151; font-size: 13px; }
QLineEdit:focus, QSpinBox:focus, QComboBox:focus { border: 1px solid #DC2626; }
QProgressBar { background: #E5E7EB; border: none; border-radius: 4px; height: 8px; }
QProgressBar::chunk { background: #DC2626; border-radius: 4px; }
QTextEdit { background: #FFFFFF; border: 1px solid #E5E7EB; border-radius: 8px;
    color: #374151; font-size: 12px; padding: 8px; }
QCheckBox { color: #374151; font-size: 13px; }
QCheckBox::indicator:checked { background: #DC2626; border: none; border-radius: 3px; }
QGroupBox { border: 1px solid #E5E7EB; border-radius: 8px; margin-top: 12px;
    font-size: 12px; font-weight: bold; color: #374151; padding: 8px; }
QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 4px; }
QScrollBar:vertical { background: #F3F4F6; width: 6px; border-radius: 3px; }
QScrollBar::handle:vertical { background: #D1D5DB; border-radius: 3px; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QTabWidget::pane { border: 1px solid #E5E7EB; border-radius: 8px; background: #FFFFFF; }
QTabBar::tab { background: #F3F4F6; color: #6B7280; padding: 8px 16px;
    border-radius: 6px 6px 0 0; font-size: 12px; margin-right: 2px; }
QTabBar::tab:selected { background: #FFFFFF; color: #DC2626; font-weight: bold; }
"""

DARK_THEME = """
QMainWindow, QWidget#central { background: #111827; }
QWidget#sidebar { background: #1F2937; border-right: 1px solid #374151; }
QWidget#topbar { background: #1F2937; border-bottom: 1px solid #374151; }
QWidget#statusbar_widget { background: #1F2937; border-top: 1px solid #374151; }
QWidget#content_area { background: #111827; }
QLabel#app_title { color: #F9FAFB; font-size: 15px; font-weight: bold; }
QLabel#nav_section_label { color: #6B7280; font-size: 10px; }
QPushButton#nav_btn { background: transparent; border: none; border-radius: 8px;
    color: #9CA3AF; text-align: left; padding: 8px 12px; font-size: 13px; }
QPushButton#nav_btn:hover { background: #374151; color: #F9FAFB; }
QPushButton#nav_btn[active="true"] { background: #7F1D1D; color: #FCA5A5; font-weight: bold; }
QPushButton#open_btn { background: #DC2626; color: white; border: none;
    border-radius: 8px; padding: 8px 18px; font-size: 13px; font-weight: bold; }
QPushButton#open_btn:hover { background: #B91C1C; }
QWidget#tool_card { background: #1F2937; border: 1px solid #374151; border-radius: 10px; }
QWidget#tool_card:hover { border: 1px solid #DC2626; }
QLabel#tool_name { color: #F9FAFB; font-size: 12px; font-weight: bold; }
QLabel#tool_desc { color: #9CA3AF; font-size: 10px; }
QLabel#section_title { color: #9CA3AF; font-size: 11px; font-weight: bold; }
QLabel#page_title { color: #F9FAFB; font-size: 17px; font-weight: bold; }
QLabel#page_subtitle { color: #9CA3AF; font-size: 12px; }
QLabel#status_text { color: #9CA3AF; font-size: 11px; }
QPushButton#action_btn { background: #DC2626; color: white; border: none;
    border-radius: 8px; padding: 10px 20px; font-size: 13px; font-weight: bold; }
QPushButton#action_btn:hover { background: #B91C1C; }
QPushButton#action_btn:disabled { background: #374151; color: #6B7280; }
QPushButton#secondary_btn { background: #374151; color: #D1D5DB; border: 1px solid #4B5563;
    border-radius: 8px; padding: 8px 16px; font-size: 13px; }
QPushButton#secondary_btn:hover { background: #4B5563; }
QListWidget { background: #1F2937; border: 1px solid #374151; border-radius: 8px;
    color: #D1D5DB; font-size: 12px; }
QListWidget::item { padding: 6px 10px; border-bottom: 1px solid #374151; }
QListWidget::item:selected { background: #7F1D1D; color: #FCA5A5; }
QLineEdit, QSpinBox, QComboBox { background: #374151; border: 1px solid #4B5563;
    border-radius: 6px; padding: 6px 10px; color: #F9FAFB; font-size: 13px; }
QLineEdit:focus, QSpinBox:focus, QComboBox:focus { border: 1px solid #DC2626; }
QProgressBar { background: #374151; border: none; border-radius: 4px; height: 8px; }
QProgressBar::chunk { background: #DC2626; border-radius: 4px; }
QTextEdit { background: #1F2937; border: 1px solid #374151; border-radius: 8px;
    color: #D1D5DB; font-size: 12px; padding: 8px; }
QCheckBox { color: #D1D5DB; font-size: 13px; }
QCheckBox::indicator:checked { background: #DC2626; border: none; border-radius: 3px; }
QGroupBox { border: 1px solid #374151; border-radius: 8px; margin-top: 12px;
    font-size: 12px; font-weight: bold; color: #9CA3AF; padding: 8px; }
QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 4px; }
QScrollBar:vertical { background: #1F2937; width: 6px; border-radius: 3px; }
QScrollBar::handle:vertical { background: #4B5563; border-radius: 3px; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QTabWidget::pane { border: 1px solid #374151; border-radius: 8px; background: #1F2937; }
QTabBar::tab { background: #374151; color: #9CA3AF; padding: 8px 16px;
    border-radius: 6px 6px 0 0; font-size: 12px; margin-right: 2px; }
QTabBar::tab:selected { background: #1F2937; color: #DC2626; font-weight: bold; }
"""

# ── Worker Thread ─────────────────────────────────────────────────────────────

class Worker(QThread):
    progress = pyqtSignal(int)
    status   = pyqtSignal(str)
    finished = pyqtSignal(bool, str)

    def __init__(self, func, *args, **kwargs):
        super().__init__()
        self.func   = func
        self.args   = args
        self.kwargs = kwargs

    def run(self):
        try:
            result = self.func(*self.args, progress_cb=self.progress.emit,
                               status_cb=self.status.emit, **self.kwargs)
            self.finished.emit(True, result or "Done!")
        except Exception as e:
            self.finished.emit(False, str(e))

# ── Drop Zone ─────────────────────────────────────────────────────────────────

class DropZone(QWidget):
    files_dropped = pyqtSignal(list)

    def __init__(self, label="Drop PDF files here\nor click to browse",
                 multi=False, parent=None):
        super().__init__(parent)
        self.multi = multi
        self.setAcceptDrops(True)
        self.setMinimumHeight(110)
        self.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        self._build(label)

    def _build(self, label):
        lay = QVBoxLayout(self)
        lay.setAlignment(Qt.AlignmentFlag.AlignCenter)
        icon = QLabel("📂")
        icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
        icon.setStyleSheet("font-size: 28px; background: transparent;")
        txt = QLabel(label)
        txt.setAlignment(Qt.AlignmentFlag.AlignCenter)
        txt.setStyleSheet("color: #9CA3AF; font-size: 12px; background: transparent;")
        txt.setWordWrap(True)
        lay.addWidget(icon)
        lay.addWidget(txt)
        self.setStyleSheet("""
            DropZone { border: 2px dashed #D1D5DB; border-radius: 10px;
                background: transparent; }
            DropZone:hover { border-color: #DC2626; }
        """)

    def mousePressEvent(self, e):
        if self.multi:
            files, _ = QFileDialog.getOpenFileNames(
                self, "Select PDFs", "", "PDF Files (*.pdf)")
        else:
            f, _ = QFileDialog.getOpenFileName(
                self, "Select PDF", "", "PDF Files (*.pdf)")
            files = [f] if f else []
        if files:
            self.files_dropped.emit(files)

    def dragEnterEvent(self, e: QDragEnterEvent):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()

    def dropEvent(self, e: QDropEvent):
        files = [u.toLocalFile() for u in e.mimeData().urls()
                 if u.toLocalFile().lower().endswith(".pdf")]
        if files:
            self.files_dropped.emit(files)

# ── Tool Card ─────────────────────────────────────────────────────────────────

class ToolCard(QWidget):
    clicked = pyqtSignal(str)

    def __init__(self, tool_id, icon, name, desc, badge="", parent=None):
        super().__init__(parent)
        self.tool_id = tool_id
        self.setObjectName("tool_card")
        self.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        self.setFixedHeight(72)

        lay = QHBoxLayout(self)
        lay.setContentsMargins(12, 10, 12, 10)
        lay.setSpacing(10)

        ico = QLabel(icon)
        ico.setFixedSize(36, 36)
        ico.setAlignment(Qt.AlignmentFlag.AlignCenter)
        ico.setStyleSheet(f"font-size: 18px; background: {self._bg()}; "
                          f"border-radius: 8px;")

        right = QVBoxLayout()
        right.setSpacing(2)
        nm = QLabel(name)
        nm.setObjectName("tool_name")
        dc = QLabel(desc)
        dc.setObjectName("tool_desc")
        right.addWidget(nm)
        right.addWidget(dc)
        if badge:
            b = QLabel(badge)
            b.setStyleSheet("background: #FEF3C7; color: #D97706; font-size: 9px; "
                            "border-radius: 3px; padding: 1px 5px;")
            b.setFixedWidth(b.fontMetrics().horizontalAdvance(badge) + 10)
            right.addWidget(b)

        lay.addWidget(ico)
        lay.addLayout(right)
        lay.addStretch()

    def _bg(self):
        colors = ["#FEE2E2","#DBEAFE","#D1FAE5","#FEF3C7","#EDE9FE","#FCE7F3",
                  "#ECFDF5","#FFF7ED","#F0FDF4","#EFF6FF"]
        return colors[hash(self.tool_id) % len(colors)]

    def mousePressEvent(self, e):
        self.clicked.emit(self.tool_id)

# ── Base Tool Page ─────────────────────────────────────────────────────────────

class BaseToolPage(QWidget):
    status_update = pyqtSignal(str)

    def __init__(self, title, subtitle, icon, parent=None):
        super().__init__(parent)
        self.worker = None
        root = QVBoxLayout(self)
        root.setContentsMargins(28, 24, 28, 24)
        root.setSpacing(16)

        # Header
        hdr = QHBoxLayout()
        ico = QLabel(icon)
        ico.setStyleSheet("font-size: 28px;")
        ttl_box = QVBoxLayout()
        ttl_box.setSpacing(2)
        t = QLabel(title)
        t.setObjectName("page_title")
        s = QLabel(subtitle)
        s.setObjectName("page_subtitle")
        ttl_box.addWidget(t)
        ttl_box.addWidget(s)
        hdr.addWidget(ico)
        hdr.addLayout(ttl_box)
        hdr.addStretch()
        root.addLayout(hdr)

        line = QFrame()
        line.setFrameShape(QFrame.Shape.HLine)
        line.setStyleSheet("color: #E5E7EB;")
        root.addWidget(line)

        self.body = QVBoxLayout()
        self.body.setSpacing(12)
        root.addLayout(self.body)

        # Progress
        self.progress = QProgressBar()
        self.progress.setVisible(False)
        self.progress.setTextVisible(False)
        root.addWidget(self.progress)

        self.log = QTextEdit()
        self.log.setReadOnly(True)
        self.log.setMaximumHeight(100)
        self.log.setVisible(False)
        root.addWidget(self.log)

        root.addStretch()
        self.build_ui()

    def build_ui(self):
        pass

    def run_worker(self, func, *args, **kwargs):
        self.progress.setVisible(True)
        self.progress.setValue(0)
        self.log.setVisible(True)
        self.log.clear()
        self.worker = Worker(func, *args, **kwargs)
        self.worker.progress.connect(self.progress.setValue)
        self.worker.status.connect(lambda m: self.log.append(m))
        self.worker.finished.connect(self.on_done)
        self.worker.start()

    def on_done(self, ok, msg):
        self.progress.setValue(100 if ok else 0)
        color = "#16A34A" if ok else "#DC2626"
        self.log.append(f'<span style="color:{color}">{"✔ " if ok else "✘ "}{msg}</span>')
        if ok:
            self.status_update.emit(f"✔ {msg}")

    def save_path(self, default_name, filter_str="PDF Files (*.pdf)"):
        path, _ = QFileDialog.getSaveFileName(self, "Save As", default_name, filter_str)
        return path

    def msg(self, text, kind="info"):
        box = QMessageBox(self)
        box.setText(text)
        if kind == "error":
            box.setIcon(QMessageBox.Icon.Critical)
        elif kind == "warn":
            box.setIcon(QMessageBox.Icon.Warning)
        else:
            box.setIcon(QMessageBox.Icon.Information)
        box.exec()

# ═══════════════════════════════════════════════════════════════════════════════
#  TOOL IMPLEMENTATIONS
# ═══════════════════════════════════════════════════════════════════════════════

# ── 1. Merge ──────────────────────────────────────────────────────────────────
class MergePage(BaseToolPage):
    def __init__(self, p=None):
        super().__init__("Merge PDFs", "Combine multiple PDF files into one", "📑", p)

    def build_ui(self):
        dz = DropZone("Drop PDF files here to merge\nor click to browse", multi=True)
        dz.files_dropped.connect(self.add_files)
        self.body.addWidget(dz)

        self.file_list = QListWidget()
        self.file_list.setMaximumHeight(160)
        self.file_list.setDragDropMode(QAbstractItemView.DragDropMode.InternalMove)
        self.body.addWidget(QLabel("Files to merge (drag to reorder):"))
        self.body.addWidget(self.file_list)

        btns = QHBoxLayout()
        rm = QPushButton("Remove Selected")
        rm.setObjectName("secondary_btn")
        rm.clicked.connect(self.remove_selected)
        cl = QPushButton("Clear All")
        cl.setObjectName("secondary_btn")
        cl.clicked.connect(self.file_list.clear)
        go = QPushButton("⚡  Merge PDFs")
        go.setObjectName("action_btn")
        go.clicked.connect(self.run)
        btns.addWidget(rm); btns.addWidget(cl); btns.addStretch(); btns.addWidget(go)
        self.body.addLayout(btns)

    def add_files(self, files):
        for f in files:
            if not any(self.file_list.item(i).text() == f
                       for i in range(self.file_list.count())):
                self.file_list.addItem(f)

    def remove_selected(self):
        for item in self.file_list.selectedItems():
            self.file_list.takeItem(self.file_list.row(item))

    def run(self):
        files = [self.file_list.item(i).text() for i in range(self.file_list.count())]
        if len(files) < 2:
            return self.msg("Add at least 2 PDF files to merge.", "warn")
        out = self.save_path("merged.pdf")
        if not out: return
        self.run_worker(_merge_pdfs, files, out)

def _merge_pdfs(files, out, progress_cb, status_cb):
    from pypdf import PdfWriter, PdfReader
    w = PdfWriter()
    for i, f in enumerate(files):
        status_cb(f"Adding {Path(f).name}...")
        r = PdfReader(f)
        for page in r.pages:
            w.add_page(page)
        progress_cb(int((i+1)/len(files)*90))
    with open(out, "wb") as fh:
        w.write(fh)
    progress_cb(100)
    return f"Merged {len(files)} files → {Path(out).name}"

# ── 2. Split ──────────────────────────────────────────────────────────────────
class SplitPage(BaseToolPage):
    def __init__(self, p=None):
        super().__init__("Split PDF", "Split a PDF into separate pages or ranges", "✂️", p)

    def build_ui(self):
        dz = DropZone()
        dz.files_dropped.connect(lambda f: self.set_file(f[0]))
        self.body.addWidget(dz)
        self.file_lbl = QLabel("No file selected")
        self.file_lbl.setObjectName("page_subtitle")
        self.body.addWidget(self.file_lbl)

        grp = QGroupBox("Split Options")
        gl = QVBoxLayout(grp)
        self.mode_all = QCheckBox("Split into individual pages")
        self.mode_all.setChecked(True)
        self.range_lbl = QLabel("Or enter page ranges (e.g. 1-3, 5, 7-9):")
        self.range_edit = QLineEdit()
        self.range_edit.setPlaceholderText("1-3, 5, 7-9")
        gl.addWidget(self.mode_all)
        gl.addWidget(self.range_lbl)
        gl.addWidget(self.range_edit)
        self.body.addWidget(grp)

        go = QPushButton("⚡  Split PDF")
        go.setObjectName("action_btn")
        go.clicked.connect(self.run)
        self.body.addWidget(go)
        self.src = None

    def set_file(self, f):
        self.src = f
        self.file_lbl.setText(f"📄 {Path(f).name}")

    def run(self):
        if not self.src: return self.msg("Select a PDF first.", "warn")
        out_dir = QFileDialog.getExistingDirectory(self, "Select Output Folder")
        if not out_dir: return
        ranges = self.range_edit.text().strip() if not self.mode_all.isChecked() else ""
        self.run_worker(_split_pdf, self.src, out_dir, ranges)

def _split_pdf(src, out_dir, ranges, progress_cb, status_cb):
    from pypdf import PdfReader, PdfWriter
    r = PdfReader(src)
    total = len(r.pages)
    base = Path(src).stem

    if ranges:
        pages = []
        for part in ranges.split(","):
            part = part.strip()
            if "-" in part:
                a, b = part.split("-")
                pages.extend(range(int(a)-1, int(b)))
            else:
                pages.append(int(part)-1)
        for i, pi in enumerate(pages):
            w = PdfWriter()
            w.add_page(r.pages[pi])
            out = os.path.join(out_dir, f"{base}_page{pi+1}.pdf")
            with open(out, "wb") as fh: w.write(fh)
            progress_cb(int((i+1)/len(pages)*100))
            status_cb(f"Saved page {pi+1}")
        return f"Extracted {len(pages)} pages → {out_dir}"
    else:
        for i, page in enumerate(r.pages):
            w = PdfWriter()
            w.add_page(page)
            out = os.path.join(out_dir, f"{base}_page{i+1:03d}.pdf")
            with open(out, "wb") as fh: w.write(fh)
            progress_cb(int((i+1)/total*100))
            status_cb(f"Saved page {i+1}/{total}")
        return f"Split into {total} pages → {out_dir}"

# ── 3. Compress ───────────────────────────────────────────────────────────────
class CompressPage(BaseToolPage):
    def __init__(self, p=None):
        super().__init__("Compress PDF", "Reduce PDF file size", "🗜️", p)

    def build_ui(self):
        dz = DropZone()
        dz.files_dropped.connect(lambda f: self.set_file(f[0]))
        self.body.addWidget(dz)
        self.file_lbl = QLabel("No file selected")
        self.file_lbl.setObjectName("page_subtitle")
        self.body.addWidget(self.file_lbl)

        grp = QGroupBox("Compression Level")
        gl = QVBoxLayout(grp)
        self.level = QComboBox()
        self.level.addItems(["Low (best quality)", "Medium (balanced)", "High (smallest size)"])
        self.level.setCurrentIndex(1)
        gl.addWidget(self.level)
        self.body.addWidget(grp)

        go = QPushButton("⚡  Compress PDF")
        go.setObjectName("action_btn")
        go.clicked.connect(self.run)
        self.body.addWidget(go)
        self.src = None

    def set_file(self, f):
        self.src = f
        sz = os.path.getsize(f) / 1024
        self.file_lbl.setText(f"📄 {Path(f).name}  ({sz:.1f} KB)")

    def run(self):
        if not self.src: return self.msg("Select a PDF first.", "warn")
        out = self.save_path(Path(self.src).stem + "_compressed.pdf")
        if not out: return
        level = self.level.currentIndex()
        self.run_worker(_compress_pdf, self.src, out, level)

def _compress_pdf(src, out, level, progress_cb, status_cb):
    import fitz
    status_cb("Opening PDF...")
    doc = fitz.open(src)
    dpi_map = [150, 100, 72]
    dpi = dpi_map[level]
    new_doc = fitz.open()
    for i, page in enumerate(doc):
        status_cb(f"Processing page {i+1}/{len(doc)}...")
        mat = fitz.Matrix(dpi/72, dpi/72)
        pix = page.get_pixmap(matrix=mat, alpha=False)
        img_page = new_doc.new_page(width=page.rect.width, height=page.rect.height)
        img_page.insert_image(img_page.rect, pixmap=pix)
        progress_cb(int((i+1)/len(doc)*90))
    new_doc.save(out, garbage=4, deflate=True, clean=True)
    orig = os.path.getsize(src)/1024
    comp = os.path.getsize(out)/1024
    pct = (1 - comp/orig)*100
    return f"Compressed {orig:.1f} KB → {comp:.1f} KB ({pct:.1f}% saved)"

# ── 4. PDF ↔ Word ─────────────────────────────────────────────────────────────
class WordPage(BaseToolPage):
    def __init__(self, p=None):
        super().__init__("PDF ↔ Word", "Convert between PDF and Word documents", "📝", p)

    def build_ui(self):
        tabs = QTabWidget()

        # PDF → Word
        t1 = QWidget()
        l1 = QVBoxLayout(t1)
        dz1 = DropZone("Drop PDF to convert to Word")
        dz1.files_dropped.connect(lambda f: self._set(f[0], "pdf2word"))
        self.lbl_p2w = QLabel("No file selected"); self.lbl_p2w.setObjectName("page_subtitle")
        go1 = QPushButton("⚡  Convert to Word (.docx)")
        go1.setObjectName("action_btn")
        go1.clicked.connect(lambda: self._run("pdf2word"))
        l1.addWidget(dz1); l1.addWidget(self.lbl_p2w); l1.addStretch(); l1.addWidget(go1)
        tabs.addTab(t1, "PDF → Word")

        # Word → PDF
        t2 = QWidget()
        l2 = QVBoxLayout(t2)
        dz2 = DropZone("Drop Word (.docx) file to convert to PDF")
        dz2.files_dropped.connect(lambda f: self._set(f[0], "word2pdf"))
        self.lbl_w2p = QLabel("No file selected"); self.lbl_w2p.setObjectName("page_subtitle")
        go2 = QPushButton("⚡  Convert to PDF")
        go2.setObjectName("action_btn")
        go2.clicked.connect(lambda: self._run("word2pdf"))
        l2.addWidget(dz2); l2.addWidget(self.lbl_w2p); l2.addStretch(); l2.addWidget(go2)
        tabs.addTab(t2, "Word → PDF")

        self.body.addWidget(tabs)
        self.src_p2w = self.src_w2p = None

    def _set(self, f, mode):
        if mode == "pdf2word":
            self.src_p2w = f; self.lbl_p2w.setText(f"📄 {Path(f).name}")
        else:
            self.src_w2p = f; self.lbl_w2p.setText(f"📄 {Path(f).name}")

    def _run(self, mode):
        if mode == "pdf2word":
            if not self.src_p2w: return self.msg("Select a PDF first.", "warn")
            out = self.save_path(Path(self.src_p2w).stem + ".docx",
                                 "Word Documents (*.docx)")
            if not out: return
            self.run_worker(_pdf_to_word, self.src_p2w, out)
        else:
            if not self.src_w2p: return self.msg("Select a Word file first.", "warn")
            out = self.save_path(Path(self.src_w2p).stem + ".pdf")
            if not out: return
            self.run_worker(_word_to_pdf, self.src_w2p, out)

def _pdf_to_word(src, out, progress_cb, status_cb):
    import fitz
    from docx import Document
    from docx.shared import Pt
    status_cb("Extracting text from PDF...")
    doc = fitz.open(src)
    word = Document()
    for i, page in enumerate(doc):
        status_cb(f"Page {i+1}/{len(doc)}...")
        text = page.get_text()
        if i > 0:
            word.add_page_break()
        for line in text.split("\n"):
            if line.strip():
                word.add_paragraph(line)
        progress_cb(int((i+1)/len(doc)*90))
    word.save(out)
    return f"Converted to Word → {Path(out).name}"

def _word_to_pdf(src, out, progress_cb, status_cb):
    status_cb("Converting Word to PDF...")
    try:
        import subprocess
        result = subprocess.run(
            ["libreoffice", "--headless", "--convert-to", "pdf",
             "--outdir", str(Path(out).parent), src],
            capture_output=True, text=True, timeout=60)
        if result.returncode == 0:
            tmp = Path(out).parent / (Path(src).stem + ".pdf")
            if tmp != Path(out):
                shutil.move(str(tmp), out)
            progress_cb(100)
            return f"Converted to PDF → {Path(out).name}"
        else:
            raise Exception("LibreOffice not found. Install it for Word→PDF conversion.")
    except FileNotFoundError:
        raise Exception("LibreOffice required for Word→PDF. Install from libreoffice.org")

# ── 5. PDF ↔ Excel ────────────────────────────────────────────────────────────
class ExcelPage(BaseToolPage):
    def __init__(self, p=None):
        super().__init__("PDF ↔ Excel", "Convert PDF tables to Excel and back", "📊", p)

    def build_ui(self):
        dz = DropZone("Drop PDF with tables to extract to Excel")
        dz.files_dropped.connect(lambda f: self.set_file(f[0]))
        self.body.addWidget(dz)
        self.file_lbl = QLabel("No file selected"); self.file_lbl.setObjectName("page_subtitle")
        self.body.addWidget(self.file_lbl)
        go = QPushButton("⚡  Extract Tables to Excel")
        go.setObjectName("action_btn")
        go.clicked.connect(self.run)
        self.body.addWidget(go)
        self.src = None

    def set_file(self, f): self.src = f; self.file_lbl.setText(f"📄 {Path(f).name}")

    def run(self):
        if not self.src: return self.msg("Select a PDF first.", "warn")
        out = self.save_path(Path(self.src).stem + ".xlsx", "Excel Files (*.xlsx)")
        if not out: return
        self.run_worker(_pdf_to_excel, self.src, out)

def _pdf_to_excel(src, out, progress_cb, status_cb):
    import pdfplumber, openpyxl
    status_cb("Scanning for tables...")
    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    with pdfplumber.open(src) as pdf:
        sheet_num = 1
        for i, page in enumerate(pdf.pages):
            tables = page.extract_tables()
            status_cb(f"Page {i+1}: found {len(tables)} table(s)")
            for table in tables:
                ws = wb.create_sheet(f"Table_{sheet_num}")
                sheet_num += 1
                for row in table:
                    ws.append([cell or "" for cell in row])
            progress_cb(int((i+1)/len(pdf.pages)*90))
    if not wb.worksheets:
        ws = wb.create_sheet("Sheet1")
        ws.append(["No tables found in this PDF"])
    wb.save(out)
    return f"Extracted tables → {Path(out).name}"

# ── 6. PDF ↔ PowerPoint ───────────────────────────────────────────────────────
class PowerPointPage(BaseToolPage):
    def __init__(self, p=None):
        super().__init__("PDF ↔ PowerPoint", "Convert PDF pages to PowerPoint slides", "📊", p)

    def build_ui(self):
        dz = DropZone("Drop PDF to convert to PowerPoint")
        dz.files_dropped.connect(lambda f: self.set_file(f[0]))
        self.body.addWidget(dz)
        self.file_lbl = QLabel("No file selected"); self.file_lbl.setObjectName("page_subtitle")
        self.body.addWidget(self.file_lbl)
        go = QPushButton("⚡  Convert to PowerPoint")
        go.setObjectName("action_btn")
        go.clicked.connect(self.run)
        self.body.addWidget(go)
        self.src = None

    def set_file(self, f): self.src = f; self.file_lbl.setText(f"📄 {Path(f).name}")

    def run(self):
        if not self.src: return self.msg("Select a PDF first.", "warn")
        out = self.save_path(Path(self.src).stem + ".pptx",
                             "PowerPoint Files (*.pptx)")
        if not out: return
        self.run_worker(_pdf_to_pptx, self.src, out)

def _pdf_to_pptx(src, out, progress_cb, status_cb):
    import fitz
    from pptx import Presentation
    from pptx.util import Inches, Pt
    from io import BytesIO
    status_cb("Converting PDF pages to slides...")
    doc = fitz.open(src)
    prs = Presentation()
    prs.slide_width  = Inches(13.33)
    prs.slide_height = Inches(7.5)
    blank = prs.slide_layouts[6]
    for i, page in enumerate(doc):
        status_cb(f"Converting page {i+1}/{len(doc)}...")
        mat = fitz.Matrix(2, 2)
        pix = page.get_pixmap(matrix=mat)
        img_bytes = pix.tobytes("png")
        slide = prs.slides.add_slide(blank)
        buf = BytesIO(img_bytes)
        slide.shapes.add_picture(buf, 0, 0,
                                 width=prs.slide_width,
                                 height=prs.slide_height)
        progress_cb(int((i+1)/len(doc)*90))
    prs.save(out)
    return f"Created {len(doc)}-slide presentation → {Path(out).name}"

# ── 7. PDF ↔ Image ────────────────────────────────────────────────────────────
class ImagePage(BaseToolPage):
    def __init__(self, p=None):
        super().__init__("PDF ↔ Image", "Convert between PDF and images", "🖼️", p)

    def build_ui(self):
        tabs = QTabWidget()

        t1 = QWidget(); l1 = QVBoxLayout(t1)
        dz1 = DropZone("Drop PDF to convert to images")
        dz1.files_dropped.connect(lambda f: self._set(f[0], "p2i"))
        self.lbl_p2i = QLabel("No file"); self.lbl_p2i.setObjectName("page_subtitle")
        self.fmt = QComboBox(); self.fmt.addItems(["PNG","JPEG","TIFF","BMP"])
        self.dpi  = QSpinBox(); self.dpi.setRange(72,600); self.dpi.setValue(150)
        fl = QHBoxLayout()
        fl.addWidget(QLabel("Format:")); fl.addWidget(self.fmt)
        fl.addWidget(QLabel("DPI:")); fl.addWidget(self.dpi); fl.addStretch()
        go1 = QPushButton("⚡  Convert to Images"); go1.setObjectName("action_btn")
        go1.clicked.connect(lambda: self._run("p2i"))
        l1.addWidget(dz1); l1.addWidget(self.lbl_p2i)
        l1.addLayout(fl); l1.addStretch(); l1.addWidget(go1)
        tabs.addTab(t1, "PDF → Image")

        t2 = QWidget(); l2 = QVBoxLayout(t2)
        dz2 = DropZone("Drop images (PNG/JPG) to combine into PDF", multi=True)
        dz2.files_dropped.connect(lambda f: self._set_imgs(f))
        self.lbl_i2p = QLabel("No files"); self.lbl_i2p.setObjectName("page_subtitle")
        go2 = QPushButton("⚡  Convert to PDF"); go2.setObjectName("action_btn")
        go2.clicked.connect(lambda: self._run("i2p"))
        l2.addWidget(dz2); l2.addWidget(self.lbl_i2p); l2.addStretch(); l2.addWidget(go2)
        tabs.addTab(t2, "Images → PDF")

        self.body.addWidget(tabs)
        self.src_p = self.imgs = None

    def _set(self, f, mode):
        self.src_p = f; self.lbl_p2i.setText(f"📄 {Path(f).name}")

    def _set_imgs(self, files):
        self.imgs = files
        self.lbl_i2p.setText(f"📄 {len(files)} image(s) selected")

    def _run(self, mode):
        if mode == "p2i":
            if not self.src_p: return self.msg("Select a PDF first.", "warn")
            out_dir = QFileDialog.getExistingDirectory(self, "Select Output Folder")
            if not out_dir: return
            self.run_worker(_pdf_to_images, self.src_p, out_dir,
                            self.fmt.currentText(), self.dpi.value())
        else:
            if not self.imgs: return self.msg("Select images first.", "warn")
            out = self.save_path("images_combined.pdf")
            if not out: return
            self.run_worker(_images_to_pdf, self.imgs, out)

def _pdf_to_images(src, out_dir, fmt, dpi, progress_cb, status_cb):
    import fitz
    doc = fitz.open(src)
    base = Path(src).stem
    ext = fmt.lower()
    for i, page in enumerate(doc):
        status_cb(f"Rendering page {i+1}/{len(doc)}...")
        mat = fitz.Matrix(dpi/72, dpi/72)
        pix = page.get_pixmap(matrix=mat, alpha=False)
        out = os.path.join(out_dir, f"{base}_{i+1:03d}.{ext}")
        pix.save(out)
        progress_cb(int((i+1)/len(doc)*100))
    return f"Saved {len(doc)} images → {out_dir}"

def _images_to_pdf(imgs, out, progress_cb, status_cb):
    from PIL import Image as PILImage
    from pypdf import PdfWriter
    import io
    w = PdfWriter()
    for i, img_path in enumerate(imgs):
        status_cb(f"Processing {Path(img_path).name}...")
        img = PILImage.open(img_path).convert("RGB")
        buf = io.BytesIO()
        img.save(buf, "PDF")
        buf.seek(0)
        from pypdf import PdfReader
        r = PdfReader(buf)
        w.add_page(r.pages[0])
        progress_cb(int((i+1)/len(imgs)*90))
    with open(out, "wb") as fh: w.write(fh)
    return f"Created PDF from {len(imgs)} images → {Path(out).name}"

# ── 8. Rotate ─────────────────────────────────────────────────────────────────
class RotatePage(BaseToolPage):
    def __init__(self, p=None):
        super().__init__("Rotate Pages", "Rotate PDF pages", "🔃", p)

    def build_ui(self):
        dz = DropZone(); dz.files_dropped.connect(lambda f: self.set_file(f[0]))
        self.body.addWidget(dz)
        self.file_lbl = QLabel("No file"); self.file_lbl.setObjectName("page_subtitle")
        self.body.addWidget(self.file_lbl)
        grp = QGroupBox("Rotation Settings")
        gl = QVBoxLayout(grp)
        rl = QHBoxLayout()
        rl.addWidget(QLabel("Angle:"))
        self.angle = QComboBox()
        self.angle.addItems(["90° Clockwise","180°","90° Counter-clockwise"])
        rl.addWidget(self.angle); rl.addStretch()
        pl = QHBoxLayout()
        pl.addWidget(QLabel("Pages:"))
        self.pages = QLineEdit(); self.pages.setPlaceholderText("All pages, or e.g. 1,3,5-8")
        pl.addWidget(self.pages)
        gl.addLayout(rl); gl.addLayout(pl)
        self.body.addWidget(grp)
        go = QPushButton("⚡  Rotate Pages"); go.setObjectName("action_btn")
        go.clicked.connect(self.run); self.body.addWidget(go)
        self.src = None

    def set_file(self, f): self.src = f; self.file_lbl.setText(f"📄 {Path(f).name}")

    def run(self):
        if not self.src: return self.msg("Select a PDF first.", "warn")
        out = self.save_path(Path(self.src).stem + "_rotated.pdf")
        if not out: return
        angles = [90, 180, 270]
        self.run_worker(_rotate_pdf, self.src, out,
                        angles[self.angle.currentIndex()], self.pages.text().strip())

def _rotate_pdf(src, out, angle, page_str, progress_cb, status_cb):
    from pypdf import PdfReader, PdfWriter
    r = PdfReader(src); w = PdfWriter()
    total = len(r.pages)
    if page_str:
        target = set()
        for part in page_str.split(","):
            part = part.strip()
            if "-" in part:
                a,b = part.split("-")
                target.update(range(int(a)-1, int(b)))
            else:
                target.add(int(part)-1)
    else:
        target = set(range(total))
    for i, page in enumerate(r.pages):
        if i in target:
            page.rotate(angle)
        w.add_page(page)
        progress_cb(int((i+1)/total*100))
    with open(out,"wb") as fh: w.write(fh)
    return f"Rotated {len(target)} page(s) → {Path(out).name}"

# ── 9. Extract Pages ──────────────────────────────────────────────────────────
class ExtractPage(BaseToolPage):
    def __init__(self, p=None):
        super().__init__("Extract Pages", "Extract specific pages into a new PDF", "📑", p)

    def build_ui(self):
        dz = DropZone(); dz.files_dropped.connect(lambda f: self.set_file(f[0]))
        self.body.addWidget(dz)
        self.file_lbl = QLabel("No file"); self.file_lbl.setObjectName("page_subtitle")
        self.body.addWidget(self.file_lbl)
        hl = QHBoxLayout()
        hl.addWidget(QLabel("Pages to extract:"))
        self.pages = QLineEdit(); self.pages.setPlaceholderText("e.g. 1-3, 5, 7-9")
        hl.addWidget(self.pages)
        self.body.addLayout(hl)
        go = QPushButton("⚡  Extract Pages"); go.setObjectName("action_btn")
        go.clicked.connect(self.run); self.body.addWidget(go)
        self.src = None

    def set_file(self, f): self.src = f; self.file_lbl.setText(f"📄 {Path(f).name}")

    def run(self):
        if not self.src: return self.msg("Select a PDF first.", "warn")
        if not self.pages.text().strip(): return self.msg("Enter page numbers.", "warn")
        out = self.save_path(Path(self.src).stem + "_extracted.pdf")
        if not out: return
        self.run_worker(_extract_pages, self.src, out, self.pages.text().strip())

def _extract_pages(src, out, page_str, progress_cb, status_cb):
    from pypdf import PdfReader, PdfWriter
    r = PdfReader(src); w = PdfWriter()
    pages = []
    for part in page_str.split(","):
        part = part.strip()
        if "-" in part:
            a, b = part.split("-")
            pages.extend(range(int(a)-1, int(b)))
        else:
            pages.append(int(part)-1)
    for i, pi in enumerate(pages):
        w.add_page(r.pages[pi])
        progress_cb(int((i+1)/len(pages)*100))
        status_cb(f"Extracted page {pi+1}")
    with open(out,"wb") as fh: w.write(fh)
    return f"Extracted {len(pages)} pages → {Path(out).name}"

# ── 10. Delete Pages ──────────────────────────────────────────────────────────
class DeletePagesPage(BaseToolPage):
    def __init__(self, p=None):
        super().__init__("Delete Pages", "Remove specific pages from a PDF", "🗑️", p)

    def build_ui(self):
        dz = DropZone(); dz.files_dropped.connect(lambda f: self.set_file(f[0]))
        self.body.addWidget(dz)
        self.file_lbl = QLabel("No file"); self.file_lbl.setObjectName("page_subtitle")
        self.body.addWidget(self.file_lbl)
        hl = QHBoxLayout()
        hl.addWidget(QLabel("Pages to delete:"))
        self.pages = QLineEdit(); self.pages.setPlaceholderText("e.g. 1, 3, 5-8")
        hl.addWidget(self.pages)
        self.body.addLayout(hl)
        go = QPushButton("⚡  Delete Pages"); go.setObjectName("action_btn")
        go.clicked.connect(self.run); self.body.addWidget(go)
        self.src = None

    def set_file(self, f): self.src = f; self.file_lbl.setText(f"📄 {Path(f).name}")

    def run(self):
        if not self.src: return self.msg("Select a PDF first.", "warn")
        if not self.pages.text().strip(): return self.msg("Enter pages to delete.", "warn")
        out = self.save_path(Path(self.src).stem + "_deleted.pdf")
        if not out: return
        self.run_worker(_delete_pages, self.src, out, self.pages.text().strip())

def _delete_pages(src, out, page_str, progress_cb, status_cb):
    from pypdf import PdfReader, PdfWriter
    r = PdfReader(src); w = PdfWriter()
    to_del = set()
    for part in page_str.split(","):
        part = part.strip()
        if "-" in part:
            a,b = part.split("-"); to_del.update(range(int(a)-1, int(b)))
        else:
            to_del.add(int(part)-1)
    kept = 0
    for i, page in enumerate(r.pages):
        if i not in to_del:
            w.add_page(page); kept += 1
        progress_cb(int((i+1)/len(r.pages)*100))
    with open(out,"wb") as fh: w.write(fh)
    return f"Deleted {len(to_del)} page(s), kept {kept} → {Path(out).name}"

# ── 11. OCR ───────────────────────────────────────────────────────────────────
class OCRPage(BaseToolPage):
    def __init__(self, p=None):
        super().__init__("PDF OCR", "Make scanned PDFs text-searchable", "🔍", p)

    def build_ui(self):
        dz = DropZone(); dz.files_dropped.connect(lambda f: self.set_file(f[0]))
        self.body.addWidget(dz)
        self.file_lbl = QLabel("No file"); self.file_lbl.setObjectName("page_subtitle")
        self.body.addWidget(self.file_lbl)
        info = QLabel("ℹ️  Tesseract OCR must be installed on your system.\n"
                      "Download: https://github.com/UB-Mannheim/tesseract/wiki")
        info.setStyleSheet("color: #D97706; font-size: 11px; padding: 8px; "
                           "background: #FEF3C7; border-radius: 6px;")
        info.setWordWrap(True)
        self.body.addWidget(info)
        hl = QHBoxLayout()
        hl.addWidget(QLabel("Language:"))
        self.lang = QComboBox()
        self.lang.addItems(["eng (English)","fra (French)","deu (German)",
                            "spa (Spanish)","chi_sim (Chinese)","jpn (Japanese)"])
        hl.addWidget(self.lang); hl.addStretch()
        self.body.addLayout(hl)
        go = QPushButton("⚡  Run OCR"); go.setObjectName("action_btn")
        go.clicked.connect(self.run); self.body.addWidget(go)
        self.src = None

    def set_file(self, f): self.src = f; self.file_lbl.setText(f"📄 {Path(f).name}")

    def run(self):
        if not self.src: return self.msg("Select a PDF first.", "warn")
        out = self.save_path(Path(self.src).stem + "_ocr.txt", "Text Files (*.txt)")
        if not out: return
        lang = self.lang.currentText().split(" ")[0]
        self.run_worker(_ocr_pdf, self.src, out, lang)

def _ocr_pdf(src, out, lang, progress_cb, status_cb):
    try:
        import pytesseract
        from PIL import Image as PILImage
        import fitz
    except ImportError:
        raise Exception("Install: pip install pytesseract pillow pymupdf  and Tesseract app")
    doc = fitz.open(src)
    text = ""
    for i, page in enumerate(doc):
        status_cb(f"OCR page {i+1}/{len(doc)}...")
        mat = fitz.Matrix(2, 2)
        pix = page.get_pixmap(matrix=mat)
        img = PILImage.frombytes("RGB", [pix.width, pix.height], pix.samples)
        text += f"\n--- Page {i+1} ---\n"
        text += pytesseract.image_to_string(img, lang=lang)
        progress_cb(int((i+1)/len(doc)*100))
    with open(out,"w",encoding="utf-8") as fh: fh.write(text)
    return f"OCR complete, text saved → {Path(out).name}"

# ── 12. Protect / Encrypt ─────────────────────────────────────────────────────
class ProtectPage(BaseToolPage):
    def __init__(self, p=None):
        super().__init__("Protect PDF", "Add password protection to a PDF", "🔒", p)

    def build_ui(self):
        dz = DropZone(); dz.files_dropped.connect(lambda f: self.set_file(f[0]))
        self.body.addWidget(dz)
        self.file_lbl = QLabel("No file"); self.file_lbl.setObjectName("page_subtitle")
        self.body.addWidget(self.file_lbl)
        grp = QGroupBox("Password Settings")
        gl = QVBoxLayout(grp)
        ul = QHBoxLayout()
        ul.addWidget(QLabel("User password:"))
        self.user_pw = QLineEdit(); self.user_pw.setEchoMode(QLineEdit.EchoMode.Password)
        ul.addWidget(self.user_pw)
        ol = QHBoxLayout()
        ol.addWidget(QLabel("Owner password:"))
        self.own_pw = QLineEdit(); self.own_pw.setEchoMode(QLineEdit.EchoMode.Password)
        ol.addWidget(self.own_pw)
        self.no_print = QCheckBox("Prevent printing")
        self.no_copy  = QCheckBox("Prevent copying text")
        self.no_edit  = QCheckBox("Prevent editing")
        gl.addLayout(ul); gl.addLayout(ol)
        gl.addWidget(self.no_print); gl.addWidget(self.no_copy); gl.addWidget(self.no_edit)
        self.body.addWidget(grp)
        go = QPushButton("⚡  Protect PDF"); go.setObjectName("action_btn")
        go.clicked.connect(self.run); self.body.addWidget(go)
        self.src = None

    def set_file(self, f): self.src = f; self.file_lbl.setText(f"📄 {Path(f).name}")

    def run(self):
        if not self.src: return self.msg("Select a PDF first.", "warn")
        if not self.user_pw.text(): return self.msg("Enter a user password.", "warn")
        out = self.save_path(Path(self.src).stem + "_protected.pdf")
        if not out: return
        self.run_worker(_protect_pdf, self.src, out,
                        self.user_pw.text(), self.own_pw.text() or self.user_pw.text(),
                        self.no_print.isChecked(), self.no_copy.isChecked(),
                        self.no_edit.isChecked())

def _protect_pdf(src, out, user_pw, owner_pw, no_print, no_copy, no_edit,
                 progress_cb, status_cb):
    from pypdf import PdfReader, PdfWriter
    status_cb("Encrypting PDF...")
    r = PdfReader(src); w = PdfWriter()
    for page in r.pages: w.add_page(page)
    w.encrypt(user_password=user_pw, owner_password=owner_pw, use_128bit=True)
    with open(out,"wb") as fh: w.write(fh)
    progress_cb(100)
    return f"PDF protected → {Path(out).name}"

# ── 13. Unlock ────────────────────────────────────────────────────────────────
class UnlockPage(BaseToolPage):
    def __init__(self, p=None):
        super().__init__("Unlock PDF", "Remove password from a PDF", "🔓", p)

    def build_ui(self):
        dz = DropZone(); dz.files_dropped.connect(lambda f: self.set_file(f[0]))
        self.body.addWidget(dz)
        self.file_lbl = QLabel("No file"); self.file_lbl.setObjectName("page_subtitle")
        self.body.addWidget(self.file_lbl)
        hl = QHBoxLayout()
        hl.addWidget(QLabel("Password:"))
        self.pw = QLineEdit(); self.pw.setEchoMode(QLineEdit.EchoMode.Password)
        hl.addWidget(self.pw)
        self.body.addLayout(hl)
        go = QPushButton("⚡  Unlock PDF"); go.setObjectName("action_btn")
        go.clicked.connect(self.run); self.body.addWidget(go)
        self.src = None

    def set_file(self, f): self.src = f; self.file_lbl.setText(f"📄 {Path(f).name}")

    def run(self):
        if not self.src: return self.msg("Select a PDF first.", "warn")
        out = self.save_path(Path(self.src).stem + "_unlocked.pdf")
        if not out: return
        self.run_worker(_unlock_pdf, self.src, out, self.pw.text())

def _unlock_pdf(src, out, pw, progress_cb, status_cb):
    from pypdf import PdfReader, PdfWriter
    status_cb("Decrypting PDF...")
    r = PdfReader(src)
    if r.is_encrypted:
        if not r.decrypt(pw):
            raise Exception("Wrong password!")
    w = PdfWriter()
    for page in r.pages: w.add_page(page)
    with open(out,"wb") as fh: w.write(fh)
    progress_cb(100)
    return f"PDF unlocked → {Path(out).name}"

# ── 14. Watermark ─────────────────────────────────────────────────────────────
class WatermarkPage(BaseToolPage):
    def __init__(self, p=None):
        super().__init__("Add Watermark", "Add text or image watermark to PDF", "💧", p)

    def build_ui(self):
        dz = DropZone(); dz.files_dropped.connect(lambda f: self.set_file(f[0]))
        self.body.addWidget(dz)
        self.file_lbl = QLabel("No file"); self.file_lbl.setObjectName("page_subtitle")
        self.body.addWidget(self.file_lbl)
        grp = QGroupBox("Watermark Settings")
        gl = QVBoxLayout(grp)
        tl = QHBoxLayout(); tl.addWidget(QLabel("Text:"))
        self.wm_text = QLineEdit(); self.wm_text.setPlaceholderText("e.g. CONFIDENTIAL")
        tl.addWidget(self.wm_text)
        al = QHBoxLayout(); al.addWidget(QLabel("Opacity:"))
        self.opacity = QSlider(Qt.Orientation.Horizontal)
        self.opacity.setRange(10, 100); self.opacity.setValue(30)
        self.op_lbl = QLabel("30%")
        self.opacity.valueChanged.connect(lambda v: self.op_lbl.setText(f"{v}%"))
        al.addWidget(self.opacity); al.addWidget(self.op_lbl)
        cl = QHBoxLayout(); cl.addWidget(QLabel("Color:"))
        self.color = QComboBox()
        self.color.addItems(["Gray","Red","Blue","Green","Black"])
        cl.addWidget(self.color); cl.addStretch()
        gl.addLayout(tl); gl.addLayout(al); gl.addLayout(cl)
        self.body.addWidget(grp)
        go = QPushButton("⚡  Add Watermark"); go.setObjectName("action_btn")
        go.clicked.connect(self.run); self.body.addWidget(go)
        self.src = None

    def set_file(self, f): self.src = f; self.file_lbl.setText(f"📄 {Path(f).name}")

    def run(self):
        if not self.src: return self.msg("Select a PDF first.", "warn")
        if not self.wm_text.text().strip(): return self.msg("Enter watermark text.", "warn")
        out = self.save_path(Path(self.src).stem + "_watermarked.pdf")
        if not out: return
        color_map = {"Gray":(0.5,0.5,0.5),"Red":(1,0,0),"Blue":(0,0,1),
                     "Green":(0,0.6,0),"Black":(0,0,0)}
        self.run_worker(_add_watermark, self.src, out, self.wm_text.text(),
                        self.opacity.value()/100,
                        color_map[self.color.currentText()])

def _add_watermark(src, out, text, opacity, color, progress_cb, status_cb):
    import fitz
    doc = fitz.open(src)
    for i, page in enumerate(doc):
        status_cb(f"Watermarking page {i+1}/{len(doc)}...")
        rect = page.rect
        fs = min(rect.width, rect.height) / 8
        page.insert_text(
            fitz.Point(rect.width*0.15, rect.height*0.55),
            text, fontsize=fs,
            color=color, rotate=45,
            fill_opacity=opacity
        )
        progress_cb(int((i+1)/len(doc)*100))
    doc.save(out)
    return f"Watermark added → {Path(out).name}"

# ── 15. Remove Watermark ──────────────────────────────────────────────────────
class RemoveWatermarkPage(BaseToolPage):
    def __init__(self, p=None):
        super().__init__("Remove Watermark", "Remove text and image watermarks from PDF", "🪄", p)

    def build_ui(self):
        dz = DropZone(); dz.files_dropped.connect(lambda f: self.set_file(f[0]))
        self.body.addWidget(dz)
        self.file_lbl = QLabel("No file"); self.file_lbl.setObjectName("page_subtitle")
        self.body.addWidget(self.file_lbl)

        grp = QGroupBox("Removal Options")
        gl = QVBoxLayout(grp)
        self.rm_text_wm = QCheckBox("Remove text watermarks (text annotations & overlays)")
        self.rm_text_wm.setChecked(True)
        self.rm_img_wm  = QCheckBox("Remove image watermarks (background images / stamps)")
        self.rm_img_wm.setChecked(True)
        self.rm_annots  = QCheckBox("Remove all annotations / stamps")
        self.wm_keyword = QLineEdit()
        self.wm_keyword.setPlaceholderText("Optional: keyword to target (e.g. CONFIDENTIAL)")
        gl.addWidget(self.rm_text_wm)
        gl.addWidget(self.rm_img_wm)
        gl.addWidget(self.rm_annots)
        gl.addWidget(QLabel("Target keyword (leave blank to remove all):"))
        gl.addWidget(self.wm_keyword)
        self.body.addWidget(grp)

        note = QLabel("ℹ️  Results depend on how the watermark was embedded. "
                       "Flattened/burned-in watermarks cannot be removed.")
        note.setWordWrap(True)
        note.setStyleSheet("color:#D97706;background:#FEF3C7;padding:8px;border-radius:6px;font-size:11px;")
        self.body.addWidget(note)

        go = QPushButton("⚡  Remove Watermark"); go.setObjectName("action_btn")
        go.clicked.connect(self.run); self.body.addWidget(go)
        self.src = None

    def set_file(self, f): self.src = f; self.file_lbl.setText(f"📄 {Path(f).name}")

    def run(self):
        if not self.src: return self.msg("Select a PDF first.", "warn")
        out = self.save_path(Path(self.src).stem + "_no_watermark.pdf")
        if not out: return
        self.run_worker(_remove_watermark, self.src, out,
                        self.rm_text_wm.isChecked(),
                        self.rm_img_wm.isChecked(),
                        self.rm_annots.isChecked(),
                        self.wm_keyword.text().strip().lower())

def _remove_watermark(src, out, rm_text, rm_img, rm_annots, keyword,
                      progress_cb, status_cb):
    import fitz, re as _re

    doc  = fitz.open(src)
    removed = 0
    keyword_lower = keyword.strip().lower()

    # ── helper: does a span look like a watermark? ────────────────────────────
    def _is_watermark_span(span):
        txt   = span.get("text", "").strip()
        flags = span.get("flags", 0)
        color = span.get("color", 0)
        size  = span.get("size", 0)
        if not txt:
            return False
        # keyword match mode
        if keyword_lower:
            return keyword_lower in txt.lower()
        # heuristic mode: large, grey-ish, short text → likely watermark
        r = (color >> 16 & 0xFF) / 255
        g = (color >>  8 & 0xFF) / 255
        b = (color       & 0xFF) / 255
        brightness = 0.299*r + 0.587*g + 0.114*b
        looks_grey   = abs(r-g) < 0.12 and abs(g-b) < 0.12  # grey/near-grey
        large_font   = size >= 18
        short_text   = len(txt) <= 50
        return looks_grey and large_font and short_text

    # ── pass 1: xref-level – remove images that carry an SMask (transparency) ─
    # These are almost always watermark images.  We blank their stream instead
    # of deleting the xref (deletion can corrupt xref tables in complex PDFs).
    if rm_img:
        status_cb("Scanning image xrefs for transparent watermark images...")
        xref_len = doc.xref_length()
        blanked_xrefs = set()
        for xref in range(1, xref_len):
            try:
                if not doc.xref_is_stream(xref):
                    continue
                obj_str = doc.xref_object(xref, compressed=False)
                if "/Image" not in obj_str and "/XObject" not in obj_str:
                    continue
                # Has a soft-mask → semi-transparent → watermark candidate
                has_smask = "/SMask" in obj_str
                is_full_page_img = False
                # Check dimensions against page sizes
                w_match = _re.search(r"/Width\s+(\d+)", obj_str)
                h_match = _re.search(r"/Height\s+(\d+)", obj_str)
                if w_match and h_match:
                    iw, ih = int(w_match.group(1)), int(h_match.group(1))
                    for page in doc:
                        if iw >= page.rect.width * 1.5 and ih >= page.rect.height * 1.5:
                            is_full_page_img = True
                            break
                if has_smask or (is_full_page_img and not keyword_lower):
                    # Replace stream content with a 1x1 white pixel PNG
                    import struct, zlib
                    white_px = (
                        b'\x89PNG\r\n\x1a\n'
                        b'\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01'
                        b'\x08\x02\x00\x00\x00\x90wS\xde\x00\x00\x00\x0cIDATx'
                        b'\x9cc\xf8\x0f\x00\x00\x01\x01\x00\x05\x18\xd8N\x00'
                        b'\x00\x00\x00IEND\xaeB`\x82'
                    )
                    doc.update_stream(xref, white_px)
                    blanked_xrefs.add(xref)
                    removed += 1
                    status_cb(f"  Blanked watermark image xref {xref} "
                              f"({'has SMask' if has_smask else 'full-page image'})")
            except Exception:
                pass

    # ── pass 2: page level ────────────────────────────────────────────────────
    for i, page in enumerate(doc):
        status_cb(f"Processing page {i+1}/{len(doc)}...")

        # ── 2a: annotations / stamps ─────────────────────────────────────────
        if rm_annots:
            annots = list(page.annots())
            for annot in annots:
                content = annot.info.get("content", "").lower()
                subject = annot.info.get("subject", "").lower()
                if (not keyword_lower
                        or keyword_lower in content
                        or keyword_lower in subject):
                    page.delete_annot(annot)
                    removed += 1
                    status_cb(f"  Removed annotation on page {i+1}")

        # ── 2b: text watermarks via redaction ────────────────────────────────
        if rm_text:
            blocks       = page.get_text("dict", flags=fitz.TEXT_PRESERVE_WHITESPACE)["blocks"]
            redact_rects = []
            for block in blocks:
                if block.get("type") != 0:
                    continue
                for line in block.get("lines", []):
                    for span in line.get("spans", []):
                        if _is_watermark_span(span):
                            redact_rects.append(fitz.Rect(span["bbox"]))
                            removed += 1
                            status_cb(f"  Redacting text '{span.get('text','').strip()[:30]}' "
                                      f"on page {i+1}")
            for rect in redact_rects:
                page.add_redact_annot(rect, fill=(1, 1, 1))  # white fill
            if redact_rects:
                page.apply_redactions()

        # ── 2c: watermark drawn via page content stream (gs/q/Q operators) ───
        # Some watermarks are painted directly with graphics operators.
        # We rewrite the content stream to strip transparent graphic states.
        if rm_img or rm_text:
            try:
                raw = page.read_contents()
                if raw:
                    text = raw.decode("latin-1", errors="replace")
                    # Remove blocks wrapped in q...Q that set a low alpha (ca/CA)
                    # Pattern: q ... ca 0.\d+ ... Q  (transparency group)
                    cleaned = _re.sub(
                        r'q\s[^qQ]{0,2000}?(?:ca|CA)\s+0\.[0-4]\d*\s[^qQ]{0,2000}?Q\s',
                        '', text, flags=_re.DOTALL)
                    if cleaned != text:
                        page.clean_contents()
                        removed += 1
                        status_cb(f"  Stripped transparent graphics layer on page {i+1}")
            except Exception as e:
                status_cb(f"  Content stream note page {i+1}: {e}")

        progress_cb(int((i+1) / len(doc) * 90))

    status_cb("Saving cleaned PDF...")
    doc.save(out, garbage=4, deflate=True, clean=True)
    progress_cb(100)

    if removed == 0:
        return (f"No watermarks detected → {Path(out).name}\n"
                f"Tip: if the watermark is burned-in (flattened), "
                f"try entering its exact keyword in the target field.")
    return f"Removed {removed} watermark element(s) → {Path(out).name}"

# ── 16. Redact ────────────────────────────────────────────────────────────────
class RedactPage(BaseToolPage):
    def __init__(self, p=None):
        super().__init__("Redact", "Permanently black out sensitive content", "⬛", p)

    def build_ui(self):
        dz = DropZone(); dz.files_dropped.connect(lambda f: self.set_file(f[0]))
        self.body.addWidget(dz)
        self.file_lbl = QLabel("No file"); self.file_lbl.setObjectName("page_subtitle")
        self.body.addWidget(self.file_lbl)
        grp = QGroupBox("Redaction Options")
        gl = QVBoxLayout(grp)
        gl.addWidget(QLabel("Search text to redact (one per line):"))
        self.terms = QTextEdit(); self.terms.setMaximumHeight(100)
        self.terms.setPlaceholderText("e.g.\nJohn Doe\n555-1234\nconfidential@email.com")
        self.case_sens = QCheckBox("Case sensitive")
        gl.addWidget(self.terms); gl.addWidget(self.case_sens)
        self.body.addWidget(grp)
        go = QPushButton("⚡  Apply Redactions"); go.setObjectName("action_btn")
        go.clicked.connect(self.run); self.body.addWidget(go)
        self.src = None

    def set_file(self, f): self.src = f; self.file_lbl.setText(f"📄 {Path(f).name}")

    def run(self):
        if not self.src: return self.msg("Select a PDF first.", "warn")
        terms = [t.strip() for t in self.terms.toPlainText().split("\n") if t.strip()]
        if not terms: return self.msg("Enter at least one term to redact.", "warn")
        out = self.save_path(Path(self.src).stem + "_redacted.pdf")
        if not out: return
        self.run_worker(_redact_pdf, self.src, out, terms, self.case_sens.isChecked())

def _redact_pdf(src, out, terms, case_sens, progress_cb, status_cb):
    import fitz
    doc = fitz.open(src)
    total_hits = 0
    for i, page in enumerate(doc):
        status_cb(f"Scanning page {i+1}/{len(doc)}...")
        for term in terms:
            flags = 0 if case_sens else fitz.TEXT_DEHYPHENATE
            hits = page.search_for(term, flags=flags)
            for rect in hits:
                page.add_redact_annot(rect, fill=(0,0,0))
                total_hits += 1
        page.apply_redactions()
        progress_cb(int((i+1)/len(doc)*100))
    doc.save(out, garbage=4, deflate=True)
    return f"Redacted {total_hits} instance(s) → {Path(out).name}"

# ── 17. Sign ──────────────────────────────────────────────────────────────────
class SignPage(BaseToolPage):
    def __init__(self, p=None):
        super().__init__("Sign PDF", "Add a text signature to PDF", "✒️", p)

    def build_ui(self):
        dz = DropZone(); dz.files_dropped.connect(lambda f: self.set_file(f[0]))
        self.body.addWidget(dz)
        self.file_lbl = QLabel("No file"); self.file_lbl.setObjectName("page_subtitle")
        self.body.addWidget(self.file_lbl)
        grp = QGroupBox("Signature")
        gl = QVBoxLayout(grp)
        sl = QHBoxLayout(); sl.addWidget(QLabel("Signature text:"))
        self.sig_text = QLineEdit(); self.sig_text.setPlaceholderText("Your Name")
        sl.addWidget(self.sig_text)
        pl = QHBoxLayout(); pl.addWidget(QLabel("Page:"))
        self.page_num = QSpinBox(); self.page_num.setMinimum(1); self.page_num.setValue(1)
        pl.addWidget(self.page_num)
        pl.addWidget(QLabel("Position:"))
        self.position = QComboBox()
        self.position.addItems(["Bottom Right","Bottom Left","Bottom Center","Top Right","Top Left"])
        pl.addWidget(self.position); pl.addStretch()
        gl.addLayout(sl); gl.addLayout(pl)
        self.body.addWidget(grp)
        go = QPushButton("⚡  Add Signature"); go.setObjectName("action_btn")
        go.clicked.connect(self.run); self.body.addWidget(go)
        self.src = None

    def set_file(self, f): self.src = f; self.file_lbl.setText(f"📄 {Path(f).name}")

    def run(self):
        if not self.src: return self.msg("Select a PDF first.", "warn")
        if not self.sig_text.text().strip(): return self.msg("Enter signature text.", "warn")
        out = self.save_path(Path(self.src).stem + "_signed.pdf")
        if not out: return
        self.run_worker(_sign_pdf, self.src, out,
                        self.sig_text.text(), self.page_num.value()-1,
                        self.position.currentText())

def _sign_pdf(src, out, sig_text, page_idx, position, progress_cb, status_cb):
    import fitz
    doc = fitz.open(src)
    page = doc[min(page_idx, len(doc)-1)]
    rect = page.rect
    margin = 40
    pos_map = {
        "Bottom Right": fitz.Point(rect.width-margin, rect.height-margin),
        "Bottom Left":  fitz.Point(margin, rect.height-margin),
        "Bottom Center":fitz.Point(rect.width/2, rect.height-margin),
        "Top Right":    fitz.Point(rect.width-margin, margin+30),
        "Top Left":     fitz.Point(margin, margin+30),
    }
    pt = pos_map[position]
    status_cb(f"Adding signature on page {page_idx+1}...")
    # Draw signature box
    sig_rect = fitz.Rect(pt.x-160, pt.y-30, pt.x+10, pt.y+10)
    page.draw_rect(sig_rect, color=(0.2,0.2,0.6), width=1)
    page.insert_text(fitz.Point(pt.x-155, pt.y-5),
                     sig_text, fontsize=16,
                     color=(0.1,0.1,0.5), fontname="helv")
    page.insert_text(fitz.Point(pt.x-155, pt.y+5),
                     f"Date: {datetime.now().strftime('%Y-%m-%d')}",
                     fontsize=8, color=(0.4,0.4,0.4))
    doc.save(out)
    progress_cb(100)
    return f"Signature added → {Path(out).name}"

# ── 18. Number Pages ──────────────────────────────────────────────────────────
class NumberPagesPage(BaseToolPage):
    def __init__(self, p=None):
        super().__init__("Number Pages", "Add page numbers to PDF", "🔢", p)

    def build_ui(self):
        dz = DropZone(); dz.files_dropped.connect(lambda f: self.set_file(f[0]))
        self.body.addWidget(dz)
        self.file_lbl = QLabel("No file"); self.file_lbl.setObjectName("page_subtitle")
        self.body.addWidget(self.file_lbl)
        grp = QGroupBox("Page Number Settings")
        gl = QVBoxLayout(grp)
        sl = QHBoxLayout(); sl.addWidget(QLabel("Start at:"))
        self.start = QSpinBox(); self.start.setMinimum(1); self.start.setValue(1)
        sl.addWidget(self.start)
        pl = QHBoxLayout(); pl.addWidget(QLabel("Position:"))
        self.pos = QComboBox()
        self.pos.addItems(["Bottom Center","Bottom Right","Bottom Left","Top Center","Top Right"])
        pl.addWidget(self.pos); pl.addStretch()
        fl = QHBoxLayout(); fl.addWidget(QLabel("Format:"))
        self.fmt = QComboBox()
        self.fmt.addItems(["1, 2, 3","Page 1 of N","- 1 -"])
        fl.addWidget(self.fmt); fl.addStretch()
        gl.addLayout(sl); gl.addLayout(pl); gl.addLayout(fl)
        self.body.addWidget(grp)
        go = QPushButton("⚡  Add Page Numbers"); go.setObjectName("action_btn")
        go.clicked.connect(self.run); self.body.addWidget(go)
        self.src = None

    def set_file(self, f): self.src = f; self.file_lbl.setText(f"📄 {Path(f).name}")

    def run(self):
        if not self.src: return self.msg("Select a PDF first.", "warn")
        out = self.save_path(Path(self.src).stem + "_numbered.pdf")
        if not out: return
        self.run_worker(_number_pages, self.src, out,
                        self.start.value(), self.pos.currentText(),
                        self.fmt.currentIndex())

def _number_pages(src, out, start, position, fmt_idx, progress_cb, status_cb):
    import fitz
    doc = fitz.open(src)
    total = len(doc)
    for i, page in enumerate(doc):
        rect = page.rect
        n = i + start
        fmt_strs = [str(n), f"Page {n} of {total}", f"- {n} -"]
        label = fmt_strs[fmt_idx]
        margin = 28
        pos_map = {
            "Bottom Center": fitz.Point(rect.width/2 - 20, rect.height - margin),
            "Bottom Right":  fitz.Point(rect.width - 50, rect.height - margin),
            "Bottom Left":   fitz.Point(margin, rect.height - margin),
            "Top Center":    fitz.Point(rect.width/2 - 20, margin),
            "Top Right":     fitz.Point(rect.width - 50, margin),
        }
        page.insert_text(pos_map[position], label, fontsize=10, color=(0.3,0.3,0.3))
        progress_cb(int((i+1)/total*100))
        status_cb(f"Numbered page {i+1}/{total}")
    doc.save(out)
    return f"Page numbers added → {Path(out).name}"

# ── 19. Crop ──────────────────────────────────────────────────────────────────
class CropPage(BaseToolPage):
    def __init__(self, p=None):
        super().__init__("Crop PDF", "Crop margins from PDF pages", "✂️", p)

    def build_ui(self):
        dz = DropZone(); dz.files_dropped.connect(lambda f: self.set_file(f[0]))
        self.body.addWidget(dz)
        self.file_lbl = QLabel("No file"); self.file_lbl.setObjectName("page_subtitle")
        self.body.addWidget(self.file_lbl)
        grp = QGroupBox("Crop Margins (points, 1 pt ≈ 0.35mm)")
        gl = QGridLayout(grp)
        self.top    = QSpinBox(); self.top.setRange(0,500);    self.top.setValue(0)
        self.bottom = QSpinBox(); self.bottom.setRange(0,500); self.bottom.setValue(0)
        self.left   = QSpinBox(); self.left.setRange(0,500);   self.left.setValue(0)
        self.right  = QSpinBox(); self.right.setRange(0,500);  self.right.setValue(0)
        gl.addWidget(QLabel("Top:"),    0, 0); gl.addWidget(self.top,    0, 1)
        gl.addWidget(QLabel("Bottom:"), 1, 0); gl.addWidget(self.bottom, 1, 1)
        gl.addWidget(QLabel("Left:"),   0, 2); gl.addWidget(self.left,   0, 3)
        gl.addWidget(QLabel("Right:"),  1, 2); gl.addWidget(self.right,  1, 3)
        self.body.addWidget(grp)
        go = QPushButton("⚡  Crop PDF"); go.setObjectName("action_btn")
        go.clicked.connect(self.run); self.body.addWidget(go)
        self.src = None

    def set_file(self, f): self.src = f; self.file_lbl.setText(f"📄 {Path(f).name}")

    def run(self):
        if not self.src: return self.msg("Select a PDF first.", "warn")
        out = self.save_path(Path(self.src).stem + "_cropped.pdf")
        if not out: return
        self.run_worker(_crop_pdf, self.src, out,
                        self.top.value(), self.bottom.value(),
                        self.left.value(), self.right.value())

def _crop_pdf(src, out, top, bottom, left, right, progress_cb, status_cb):
    import fitz
    doc = fitz.open(src)
    for i, page in enumerate(doc):
        r = page.rect
        new_rect = fitz.Rect(r.x0+left, r.y0+top, r.x1-right, r.y1-bottom)
        page.set_cropbox(new_rect)
        progress_cb(int((i+1)/len(doc)*100))
        status_cb(f"Cropped page {i+1}/{len(doc)}")
    doc.save(out)
    return f"Cropped all pages → {Path(out).name}"

# ── 20. Flatten ───────────────────────────────────────────────────────────────
class FlattenPage(BaseToolPage):
    def __init__(self, p=None):
        super().__init__("Flatten PDF", "Flatten form fields and annotations into page content", "📥", p)

    def build_ui(self):
        dz = DropZone(); dz.files_dropped.connect(lambda f: self.set_file(f[0]))
        self.body.addWidget(dz)
        self.file_lbl = QLabel("No file"); self.file_lbl.setObjectName("page_subtitle")
        self.body.addWidget(self.file_lbl)
        info = QLabel("Flattening merges form fields and annotations permanently into the page, "
                      "preventing further editing of those elements.")
        info.setWordWrap(True); info.setObjectName("page_subtitle")
        self.body.addWidget(info)
        go = QPushButton("⚡  Flatten PDF"); go.setObjectName("action_btn")
        go.clicked.connect(self.run); self.body.addWidget(go)
        self.src = None

    def set_file(self, f): self.src = f; self.file_lbl.setText(f"📄 {Path(f).name}")

    def run(self):
        if not self.src: return self.msg("Select a PDF first.", "warn")
        out = self.save_path(Path(self.src).stem + "_flat.pdf")
        if not out: return
        self.run_worker(_flatten_pdf, self.src, out)

def _flatten_pdf(src, out, progress_cb, status_cb):
    import fitz
    status_cb("Flattening annotations and form fields...")
    doc = fitz.open(src)
    for i, page in enumerate(doc):
        page.clean_contents()
        for annot in list(page.annots()):
            page.delete_annot(annot)
        progress_cb(int((i+1)/len(doc)*90))
    doc.save(out, garbage=4, deflate=True, clean=True)
    progress_cb(100)
    return f"PDF flattened → {Path(out).name}"

# ── 21. Annotate ──────────────────────────────────────────────────────────────
class AnnotatePage(BaseToolPage):
    def __init__(self, p=None):
        super().__init__("Annotate", "Add text notes and highlights to PDF", "✍️", p)

    def build_ui(self):
        dz = DropZone(); dz.files_dropped.connect(lambda f: self.set_file(f[0]))
        self.body.addWidget(dz)
        self.file_lbl = QLabel("No file"); self.file_lbl.setObjectName("page_subtitle")
        self.body.addWidget(self.file_lbl)
        grp = QGroupBox("Add Text Annotation")
        gl = QVBoxLayout(grp)
        self.note_text = QTextEdit(); self.note_text.setMaximumHeight(80)
        self.note_text.setPlaceholderText("Enter your note text here...")
        pl = QHBoxLayout()
        pl.addWidget(QLabel("Page:")); self.ann_page = QSpinBox(); self.ann_page.setMinimum(1)
        pl.addWidget(self.ann_page); pl.addStretch()
        self.ann_color = QComboBox()
        self.ann_color.addItems(["Yellow","Green","Blue","Red","Pink"])
        pl.addWidget(QLabel("Color:")); pl.addWidget(self.ann_color)
        gl.addWidget(self.note_text); gl.addLayout(pl)
        self.body.addWidget(grp)
        go = QPushButton("⚡  Add Annotation"); go.setObjectName("action_btn")
        go.clicked.connect(self.run); self.body.addWidget(go)
        self.src = None

    def set_file(self, f): self.src = f; self.file_lbl.setText(f"📄 {Path(f).name}")

    def run(self):
        if not self.src: return self.msg("Select a PDF first.", "warn")
        if not self.note_text.toPlainText().strip(): return self.msg("Enter annotation text.", "warn")
        out = self.save_path(Path(self.src).stem + "_annotated.pdf")
        if not out: return
        colors = {"Yellow":(1,1,0),"Green":(0,1,0),"Blue":(0,0.7,1),
                  "Red":(1,0.3,0.3),"Pink":(1,0.7,0.9)}
        self.run_worker(_annotate_pdf, self.src, out,
                        self.note_text.toPlainText(), self.ann_page.value()-1,
                        colors[self.ann_color.currentText()])

def _annotate_pdf(src, out, text, page_idx, color, progress_cb, status_cb):
    import fitz
    doc = fitz.open(src)
    page = doc[min(page_idx, len(doc)-1)]
    rect = fitz.Rect(50, 50, 300, 80)
    annot = page.add_freetext_annot(rect, text, fontsize=10,
                                    fill_color=color, text_color=(0,0,0))
    annot.update()
    status_cb(f"Annotation added to page {page_idx+1}")
    doc.save(out)
    progress_cb(100)
    return f"Annotation added → {Path(out).name}"

# ── 22. Summarise ─────────────────────────────────────────────────────────────
class SummarisePage(BaseToolPage):
    def __init__(self, p=None):
        super().__init__("Summarise PDF", "Extract and display key text from PDF", "📋", p)

    def build_ui(self):
        dz = DropZone(); dz.files_dropped.connect(lambda f: self.set_file(f[0]))
        self.body.addWidget(dz)
        self.file_lbl = QLabel("No file"); self.file_lbl.setObjectName("page_subtitle")
        self.body.addWidget(self.file_lbl)
        grp = QGroupBox("Options")
        gl = QHBoxLayout(grp)
        gl.addWidget(QLabel("Max pages to read:"))
        self.max_pages = QSpinBox(); self.max_pages.setRange(1,200); self.max_pages.setValue(10)
        gl.addWidget(self.max_pages); gl.addStretch()
        self.body.addWidget(grp)
        go = QPushButton("⚡  Extract Text Summary"); go.setObjectName("action_btn")
        go.clicked.connect(self.run); self.body.addWidget(go)
        self.out_text = QTextEdit(); self.out_text.setReadOnly(True)
        self.out_text.setPlaceholderText("Extracted text will appear here...")
        self.body.addWidget(self.out_text)
        self.src = None

    def set_file(self, f): self.src = f; self.file_lbl.setText(f"📄 {Path(f).name}")

    def run(self):
        if not self.src: return self.msg("Select a PDF first.", "warn")
        self.out_text.clear()
        self.run_worker(_summarise_pdf, self.src, self.max_pages.value())

    def on_done(self, ok, msg):
        super().on_done(ok, msg)
        if ok and msg.startswith("TEXT:"):
            self.out_text.setPlainText(msg[5:])

def _summarise_pdf(src, max_pages, progress_cb, status_cb):
    import fitz
    doc = fitz.open(src)
    total = min(len(doc), max_pages)
    full_text = f"=== {Path(src).name} ===\n"
    full_text += f"Pages: {len(doc)} | Reading first {total}\n\n"
    for i in range(total):
        status_cb(f"Reading page {i+1}/{total}...")
        text = doc[i].get_text()
        if text.strip():
            full_text += f"--- Page {i+1} ---\n{text}\n\n"
        progress_cb(int((i+1)/total*100))
    return "TEXT:" + full_text

# ── 23. Remove Hidden Code & Scripts ──────────────────────────────────────────
class SanitisePage(BaseToolPage):
    def __init__(self, p=None):
        super().__init__("Remove Hidden Code",
                         "Strip JavaScript, embedded scripts, hidden actions & threats from PDF",
                         "🛡️", p)

    def build_ui(self):
        dz = DropZone(); dz.files_dropped.connect(lambda f: self.set_file(f[0]))
        self.body.addWidget(dz)
        self.file_lbl = QLabel("No file"); self.file_lbl.setObjectName("page_subtitle")
        self.body.addWidget(self.file_lbl)

        warn = QLabel("⚠️  PDFs from the internet can contain:\n"
                      " • JavaScript (can execute on open)\n"
                      " • Auto-launch actions (open URLs, run programs)\n"
                      " • Embedded files (hidden executables)\n"
                      " • URI actions and form submit actions\n"
                      " • Launch actions (can run system commands)\n\n"
                      "This tool removes all of the above permanently.")
        warn.setWordWrap(True)
        warn.setStyleSheet("color:#065F46;background:#D1FAE5;padding:10px;"
                           "border-radius:6px;font-size:12px;")
        self.body.addWidget(warn)

        grp = QGroupBox("What to remove")
        gl = QVBoxLayout(grp)
        self.rm_js       = QCheckBox("JavaScript (all JS actions and scripts)"); self.rm_js.setChecked(True)
        self.rm_launch   = QCheckBox("Launch actions (can execute programs)"); self.rm_launch.setChecked(True)
        self.rm_uri      = QCheckBox("URI / URL actions (auto-open links)"); self.rm_uri.setChecked(True)
        self.rm_embedded = QCheckBox("Embedded files (hidden attachments)"); self.rm_embedded.setChecked(True)
        self.rm_openact  = QCheckBox("Document open actions"); self.rm_openact.setChecked(True)
        self.rm_named    = QCheckBox("Named actions (GoToR, ImportData, etc.)"); self.rm_named.setChecked(True)
        for cb in [self.rm_js, self.rm_launch, self.rm_uri,
                   self.rm_embedded, self.rm_openact, self.rm_named]:
            gl.addWidget(cb)
        self.body.addWidget(grp)

        self.report_area = QTextEdit()
        self.report_area.setReadOnly(True)
        self.report_area.setMaximumHeight(120)
        self.report_area.setPlaceholderText("Sanitisation report will appear here...")
        self.body.addWidget(self.report_area)

        go = QPushButton("🛡️  Sanitise PDF Now"); go.setObjectName("action_btn")
        go.clicked.connect(self.run); self.body.addWidget(go)
        self.src = None

    def set_file(self, f): self.src = f; self.file_lbl.setText(f"📄 {Path(f).name}")

    def run(self):
        if not self.src: return self.msg("Select a PDF first.", "warn")
        out = self.save_path(Path(self.src).stem + "_sanitised.pdf")
        if not out: return
        self.report_area.clear()
        self.run_worker(_sanitise_pdf, self.src, out,
                        self.rm_js.isChecked(), self.rm_launch.isChecked(),
                        self.rm_uri.isChecked(), self.rm_embedded.isChecked(),
                        self.rm_openact.isChecked(), self.rm_named.isChecked())

    def on_done(self, ok, msg):
        super().on_done(ok, msg)
        if ok and "REPORT:" in msg:
            _, report = msg.split("REPORT:", 1)
            self.report_area.setPlainText(report)

def _sanitise_pdf(src, out, rm_js, rm_launch, rm_uri, rm_embedded,
                  rm_openact, rm_named, progress_cb, status_cb):
    import fitz, re as _re

    doc          = fitz.open(src)
    report_lines = []
    removed      = 0
    xref_count   = doc.xref_length()

    def _nuke_key(xref, key_noSlash, label):
        nonlocal removed
        try:
            v = doc.xref_get_key(xref, key_noSlash)
            if v[0] != "null":
                doc.xref_set_key(xref, key_noSlash, "null")
                report_lines.append(f"  \u2718 Removed /{key_noSlash} [{label}] \u2014 xref {xref}")
                removed += 1
                return True
        except Exception:
            pass
        return False

    def _blank_object(xref, label):
        nonlocal removed
        try:
            doc.update_object(xref, "<< >>")
            report_lines.append(f"  \u2718 Blanked {label} \u2014 xref {xref}")
            removed += 1
            return True
        except Exception:
            pass
        return False

    def _get_ref_xrefs(val_str):
        return {int(m) for m in _re.findall(r"(\d+)\s+0\s+R", val_str)}

    # ── PRE-PASS: classify every action xref as auto-triggered or manual link
    status_cb("Pre-pass \u2014 mapping auto-triggered vs manual actions...")
    progress_cb(3)

    auto_xrefs   = set()   # fire without user click -> dangerous
    manual_xrefs = set()   # user must click -> safe (book hyperlinks)

    try:
        cat = doc.pdf_catalog()

        # Catalog /OpenAction -> auto
        oa = doc.xref_get_key(cat, "OpenAction")
        if oa[0] not in ("null", ""):
            auto_xrefs |= _get_ref_xrefs(oa[1])

        for page in doc:
            px = page.xref
            # Page /AA -> auto
            aa = doc.xref_get_key(px, "AA")
            if aa[0] not in ("null", ""):
                auto_xrefs |= _get_ref_xrefs(aa[1])

            # Walk annotations
            ann_ref = doc.xref_get_key(px, "Annots")
            if ann_ref[0] not in ("null", ""):
                for ax in _get_ref_xrefs(ann_ref[1]):
                    try:
                        aobj = doc.xref_object(ax, compressed=False)
                        if not aobj:
                            continue
                        # Annot /AA -> auto
                        if "/AA" in aobj:
                            aa2 = doc.xref_get_key(ax, "AA")
                            if aa2[0] not in ("null", ""):
                                auto_xrefs |= _get_ref_xrefs(aa2[1])
                        # Annot /A -> depends on Subtype
                        if "/A" in aobj:
                            a_ref = doc.xref_get_key(ax, "A")
                            if a_ref[0] not in ("null", ""):
                                action_xrefs = _get_ref_xrefs(a_ref[1])
                                sub = doc.xref_get_key(ax, "Subtype")
                                sub_val = sub[1].strip() if sub[0] != "null" else ""
                                # /Link annots = normal user-click hyperlinks = safe
                                if "Link" in sub_val:
                                    manual_xrefs |= action_xrefs
                                else:
                                    # Widget / Screen / unknown = auto-fire risk
                                    auto_xrefs |= action_xrefs
                    except Exception:
                        pass
    except Exception as e:
        status_cb(f"  Pre-pass warning: {e}")

    # If something is in both sets, treat as dangerous
    manual_xrefs -= auto_xrefs

    # ── PASS 1: object scan
    status_cb("Pass 1/4 \u2014 scanning all PDF objects...")
    progress_cb(5)

    for xref in range(1, xref_count):
        try:
            obj_str = doc.xref_object(xref, compressed=False)
        except Exception:
            continue
        if not obj_str or obj_str.strip() in ("", "null"):
            continue

        # JavaScript: ALWAYS remove, never legitimate in downloaded PDFs
        if rm_js and ("/JavaScript" in obj_str or "/JS " in obj_str or "/JS\n" in obj_str or obj_str.endswith("/JS")):
            status_cb(f"  \u26a0 JavaScript at xref {xref}")
            hit  = _nuke_key(xref, "JS",         "JavaScript code")
            hit2 = _nuke_key(xref, "JavaScript", "JavaScript ref")
            if not hit and not hit2:
                if "/S /JavaScript" in obj_str or "/S/JavaScript" in obj_str:
                    _blank_object(xref, "JavaScript action")

        # Launch: ALWAYS remove (can execute programs)
        if rm_launch and "/Launch" in obj_str:
            status_cb(f"  \u26a0 Launch action at xref {xref}")
            if "/S /Launch" in obj_str or "/S/Launch" in obj_str:
                _blank_object(xref, "Launch action")
            else:
                _nuke_key(xref, "Launch", "Launch ref")

        # URI: ONLY remove if auto-triggered — normal book hyperlinks are safe
        if rm_uri and ("/S /URI" in obj_str or "/S/URI" in obj_str):
            if xref in auto_xrefs:
                status_cb(f"  \u26a0 Auto-triggered URI at xref {xref}")
                _blank_object(xref, "Auto-triggered URI action")
            # else: manual hyperlink — leave untouched, no report entry

        # Form actions: always dangerous (submit data without consent)
        FORM_ACTIONS = ["/SubmitForm", "/ImportData", "/ResetForm"]
        if rm_named and any(k in obj_str for k in FORM_ACTIONS):
            for ns in FORM_ACTIONS:
                if ns in obj_str:
                    status_cb(f"  \u26a0 {ns} action at xref {xref}")
                    _blank_object(xref, f"{ns} action")
                    break

        # GoToR / Named: only if auto-triggered
        if rm_named and ("/GoToR" in obj_str or "/Named" in obj_str):
            if xref in auto_xrefs:
                status_cb(f"  \u26a0 Auto-triggered GoToR/Named at xref {xref}")
                _blank_object(xref, "Auto-triggered GoToR/Named action")

        # Embedded files: always remove
        if rm_embedded and "/EmbeddedFile" in obj_str:
            status_cb(f"  \u26a0 EmbeddedFile at xref {xref}")
            _blank_object(xref, "EmbeddedFile")
        if rm_embedded and "/Filespec" in obj_str.lower():
            status_cb(f"  \u26a0 Filespec attachment at xref {xref}")
            _blank_object(xref, "Filespec attachment")

        if xref % max(1, xref_count // 30) == 0:
            progress_cb(5 + int(xref / xref_count * 55))

    # ── PASS 2: catalog
    status_cb("Pass 2/4 \u2014 cleaning document catalog...")
    progress_cb(62)
    try:
        cat = doc.pdf_catalog()
        if rm_openact:
            if _nuke_key(cat, "OpenAction", "/OpenAction in catalog"):
                status_cb("  \u26a0 OpenAction removed from catalog")

        if rm_js:
            try:
                names_ref = doc.xref_get_key(cat, "Names")
                if names_ref[0] not in ("null", ""):
                    n_str = names_ref[1].strip()
                    if _re.match(r"^\d+\s+0\s+R$", n_str):
                        n_xref = int(n_str.split()[0])
                        if _nuke_key(n_xref, "JavaScript", "/Names /JavaScript dict"):
                            status_cb("  \u26a0 Named JavaScript registry removed")
                    # Only nuke the Names dict if it still contains JS after above
                    n_obj = doc.xref_object(int(n_str.split()[0]) if _re.match(r"^\d+\s+0\s+R$", n_str) else 0,
                                            compressed=False) if _re.match(r"^\d+\s+0\s+R$", n_str) else ""
                    if n_obj and "/JavaScript" in n_obj:
                        _nuke_key(cat, "Names", "/Names dict still containing JS")
            except Exception as e:
                status_cb(f"  Names/JS: {e}")

        if rm_embedded:
            try:
                names_ref = doc.xref_get_key(cat, "Names")
                if names_ref[0] not in ("null", ""):
                    n_str = names_ref[1].strip()
                    if _re.match(r"^\d+\s+0\s+R$", n_str):
                        n_xref = int(n_str.split()[0])
                        if _nuke_key(n_xref, "EmbeddedFiles", "/Names /EmbeddedFiles"):
                            status_cb("  \u26a0 EmbeddedFiles removed")
            except Exception as e:
                status_cb(f"  EmbeddedFiles: {e}")

        if rm_js:
            try:
                af_ref = doc.xref_get_key(cat, "AcroForm")
                if af_ref[0] not in ("null", ""):
                    af_str = af_ref[1].strip()
                    if _re.match(r"^\d+\s+0\s+R$", af_str):
                        _nuke_key(int(af_str.split()[0]), "XFA", "XFA form JS")
            except Exception:
                pass
    except Exception as e:
        status_cb(f"  Catalog pass: {e}")

    # ── PASS 3: page-level /AA and annotation actions
    status_cb("Pass 3/4 \u2014 scanning pages...")
    progress_cb(70)
    for i, page in enumerate(doc):
        px = page.xref
        try:
            aa = doc.xref_get_key(px, "AA")
            if aa[0] != "null":
                doc.xref_set_key(px, "AA", "null")
                report_lines.append(f"  \u2718 Removed /AA (auto-action) on page {i+1}")
                removed += 1
                status_cb(f"  \u26a0 /AA removed from page {i+1}")
        except Exception:
            pass
        try:
            ann_ref = doc.xref_get_key(px, "Annots")
            if ann_ref[0] not in ("null", ""):
                for ax in _get_ref_xrefs(ann_ref[1]):
                    try:
                        aobj = doc.xref_object(ax, compressed=False)
                        if not aobj: continue
                        if "/AA" in aobj:
                            _nuke_key(ax, "AA", f"annot /AA pg {i+1}")
                        if "/A" in aobj and ax in auto_xrefs:
                            a_ref = doc.xref_get_key(ax, "A")
                            if a_ref[0] not in ("null", ""):
                                a_str = a_ref[1]
                                is_threat = (
                                    (rm_uri    and "URI"        in a_str) or
                                    (rm_js     and "JavaScript" in a_str) or
                                    (rm_launch and "Launch"     in a_str)
                                )
                                if is_threat:
                                    _nuke_key(ax, "A", f"auto-triggered annot action pg {i+1}")
                                    status_cb(f"  \u26a0 Auto-triggered annot action removed pg {i+1}")
                    except Exception:
                        pass
        except Exception:
            pass
        progress_cb(70 + int((i+1) / max(len(doc),1) * 15))

    # ── PASS 4: raw byte scan for obfuscated/stream-embedded threats
    status_cb("Pass 4/4 \u2014 deep byte scan...")
    progress_cb(87)
    DANGER_BYTES = []
    if rm_js:
        DANGER_BYTES += [b"/JavaScript", b"app.launchURL", b"app.alert",
                         b"getURL(", b"eval(", b"unescape("]
    if rm_launch:
        DANGER_BYTES += [b"/Launch", b"cmd.exe", b"powershell", b"wscript"]
    if rm_embedded:
        DANGER_BYTES += [b"/EmbeddedFile", b"totally_not_malware"]

    for xref in range(1, xref_count):
        try:
            if not doc.xref_is_stream(xref): continue
            raw  = doc.xref_stream_raw(xref)
            hits = [kw.decode() for kw in DANGER_BYTES if kw in raw]
            if hits:
                status_cb(f"  \u26a0 Stream xref {xref} contains: {', '.join(hits)}")
                try:
                    doc.update_stream(xref, b" ")
                    report_lines.append(f"  \u2718 Wiped dangerous stream \u2014 xref {xref} ({', '.join(hits)})")
                    removed += 1
                except Exception as se:
                    status_cb(f"    Could not wipe stream {xref}: {se}")
        except Exception:
            pass

    status_cb("Saving sanitised PDF...")
    progress_cb(93)
    doc.save(out, garbage=4, deflate=True, clean=True)
    progress_cb(100)

    if removed == 0:
        report_lines.insert(0, "\u2714 No threats found \u2014 PDF appears clean.")
    else:
        report_lines.insert(0,
            f"\u26a0 Removed {removed} dangerous element(s) across 4 scan passes:\n"
            f"  (Normal hyperlinks/bookmarks in the document were NOT touched)\n")

    return f"Sanitised: {removed} element(s) removed \u2192 {Path(out).name}\nREPORT:" + "\n".join(report_lines)


# ── 24. Remove Metadata ───────────────────────────────────────────────────────
class MetadataPage(BaseToolPage):
    def __init__(self, p=None):
        super().__init__("Remove Metadata",
                         "Strip author, software, creation date, GPS and all hidden metadata",
                         "🧹", p)

    def build_ui(self):
        dz = DropZone(); dz.files_dropped.connect(lambda f: self.set_file(f[0]))
        self.body.addWidget(dz)
        self.file_lbl = QLabel("No file"); self.file_lbl.setObjectName("page_subtitle")
        self.body.addWidget(self.file_lbl)

        info = QLabel("PDF metadata can expose: author name, company, software used, "
                      "creation & modification dates, GPS location (from scans), "
                      "computer name, and edit history (XMP). All of this is removed.")
        info.setWordWrap(True)
        info.setStyleSheet("color:#1E3A5F;background:#DBEAFE;padding:10px;"
                           "border-radius:6px;font-size:12px;")
        self.body.addWidget(info)

        grp = QGroupBox("Current Metadata Preview")
        gl = QVBoxLayout(grp)
        self.meta_view = QTextEdit()
        self.meta_view.setReadOnly(True)
        self.meta_view.setMaximumHeight(130)
        self.meta_view.setPlaceholderText("Load a PDF to preview its metadata...")
        gl.addWidget(self.meta_view)
        self.body.addWidget(grp)

        grp2 = QGroupBox("Replacement Values (leave blank to clear)")
        gl2 = QGridLayout(grp2)
        self.new_title  = QLineEdit(); self.new_title.setPlaceholderText("(blank = remove)")
        self.new_author = QLineEdit(); self.new_author.setPlaceholderText("(blank = remove)")
        gl2.addWidget(QLabel("Title:"),  0, 0); gl2.addWidget(self.new_title,  0, 1)
        gl2.addWidget(QLabel("Author:"), 1, 0); gl2.addWidget(self.new_author, 1, 1)
        self.body.addWidget(grp2)

        go = QPushButton("🧹  Strip All Metadata"); go.setObjectName("action_btn")
        go.clicked.connect(self.run); self.body.addWidget(go)
        self.src = None

    def set_file(self, f):
        self.src = f
        self.file_lbl.setText(f"📄 {Path(f).name}")
        self._preview_meta(f)

    def _preview_meta(self, f):
        try:
            import fitz
            doc = fitz.open(f)
            meta = doc.metadata
            lines = []
            for k, v in meta.items():
                if v:
                    lines.append(f"{k}: {v}")
            self.meta_view.setPlainText("\n".join(lines) if lines else "No metadata found.")
        except Exception as e:
            self.meta_view.setPlainText(f"Could not read metadata: {e}")

    def run(self):
        if not self.src: return self.msg("Select a PDF first.", "warn")
        out = self.save_path(Path(self.src).stem + "_clean_meta.pdf")
        if not out: return
        self.run_worker(_remove_metadata, self.src, out,
                        self.new_title.text(), self.new_author.text())

def _remove_metadata(src, out, new_title, new_author, progress_cb, status_cb):
    import fitz
    status_cb("Reading PDF...")
    doc = fitz.open(src)

    status_cb("Stripping standard metadata fields...")
    clean_meta = {
        "title":    new_title  or "",
        "author":   new_author or "",
        "subject":  "",
        "keywords": "",
        "creator":  "",
        "producer": "",
        "creationDate": "",
        "modDate":  "",
        "trapped":  "",
        "encryption": "",
    }
    doc.set_metadata(clean_meta)
    progress_cb(40)

    status_cb("Stripping XMP metadata (extended metadata)...")
    try:
        doc.del_xml_metadata()
    except Exception:
        pass
    progress_cb(60)

    # Remove any leftover Info dict entries
    status_cb("Cleaning Info dictionary...")
    try:
        cat = doc.pdf_catalog()
        info_ref = doc.xref_get_key(cat, "Info")
        if info_ref[0] != "null":
            keys_to_clear = ["/Title","/Author","/Subject","/Keywords",
                             "/Creator","/Producer","/CreationDate","/ModDate",
                             "/Trapped","/Company","/SourceModified","/DocSecurity"]
            try:
                info_xref = int(info_ref[1].split()[0])
                for key in keys_to_clear:
                    try:
                        doc.xref_set_key(info_xref, key.lstrip("/"), "null")
                    except Exception:
                        pass
            except Exception:
                pass
    except Exception as e:
        status_cb(f"  Info dict note: {e}")
    progress_cb(80)

    status_cb("Saving clean PDF...")
    doc.save(out, garbage=4, deflate=True, clean=True)
    progress_cb(100)
    return f"All metadata stripped → {Path(out).name}"

# ── 25. Translate ─────────────────────────────────────────────────────────────
class TranslatePage(BaseToolPage):
    def __init__(self, p=None):
        super().__init__("Translate PDF", "Extract and translate PDF text", "🌐", p)

    def build_ui(self):
        dz = DropZone(); dz.files_dropped.connect(lambda f: self.set_file(f[0]))
        self.body.addWidget(dz)
        self.file_lbl = QLabel("No file"); self.file_lbl.setObjectName("page_subtitle")
        self.body.addWidget(self.file_lbl)
        hl = QHBoxLayout()
        hl.addWidget(QLabel("Translate to:"))
        self.lang = QComboBox()
        self.lang.addItems(["English","French","German","Spanish","Portuguese",
                            "Italian","Dutch","Polish","Russian","Chinese (Simplified)",
                            "Japanese","Korean","Arabic","Hindi"])
        hl.addWidget(self.lang); hl.addStretch()
        self.body.addLayout(hl)
        info = QLabel("ℹ️  Requires internet. Uses Google Translate (free, via deep-translator).")
        info.setStyleSheet("color:#6B7280;font-size:11px;")
        self.body.addWidget(info)
        go = QPushButton("⚡  Translate & Save as TXT"); go.setObjectName("action_btn")
        go.clicked.connect(self.run); self.body.addWidget(go)
        self.src = None

    def set_file(self, f): self.src = f; self.file_lbl.setText(f"📄 {Path(f).name}")

    def run(self):
        if not self.src: return self.msg("Select a PDF first.", "warn")
        out = self.save_path(Path(self.src).stem + "_translated.txt", "Text Files (*.txt)")
        if not out: return
        lang_map = {"English":"en","French":"fr","German":"de","Spanish":"es",
                    "Portuguese":"pt","Italian":"it","Dutch":"nl","Polish":"pl",
                    "Russian":"ru","Chinese (Simplified)":"zh-CN",
                    "Japanese":"ja","Korean":"ko","Arabic":"ar","Hindi":"hi"}
        self.run_worker(_translate_pdf, self.src, out, lang_map[self.lang.currentText()])

def _translate_pdf(src, out, lang, progress_cb, status_cb):
    try:
        from deep_translator import GoogleTranslator
    except ImportError:
        raise Exception("Install: pip install deep-translator")
    import fitz
    doc = fitz.open(src)
    translator = GoogleTranslator(source="auto", target=lang)
    result = []
    for i, page in enumerate(doc):
        status_cb(f"Translating page {i+1}/{len(doc)}...")
        text = page.get_text()
        if text.strip():
            try:
                chunks = [text[j:j+4999] for j in range(0, len(text), 4999)]
                translated = " ".join(translator.translate(c) for c in chunks)
                result.append(f"--- Page {i+1} ---\n{translated}\n")
            except Exception as e:
                result.append(f"--- Page {i+1} (error: {e}) ---\n{text}\n")
        progress_cb(int((i+1)/len(doc)*100))
    with open(out,"w",encoding="utf-8") as fh:
        fh.write("\n".join(result))
    return f"Translated {len(doc)} pages → {Path(out).name}"

# ── 26. Batch Processor ───────────────────────────────────────────────────────
class BatchPage(BaseToolPage):
    def __init__(self, p=None):
        super().__init__("Batch Process", "Apply one operation to many PDFs at once", "⚡", p)

    def build_ui(self):
        dz = DropZone("Drop multiple PDFs here", multi=True)
        dz.files_dropped.connect(self.add_files)
        self.body.addWidget(dz)

        self.file_list = QListWidget(); self.file_list.setMaximumHeight(120)
        rm = QPushButton("Remove Selected"); rm.setObjectName("secondary_btn")
        rm.clicked.connect(self.remove_sel)
        cl = QPushButton("Clear"); cl.setObjectName("secondary_btn")
        cl.clicked.connect(self.file_list.clear)
        hl = QHBoxLayout(); hl.addWidget(rm); hl.addWidget(cl); hl.addStretch()
        self.body.addWidget(QLabel("Files:"))
        self.body.addWidget(self.file_list)
        self.body.addLayout(hl)

        grp = QGroupBox("Operation")
        gl = QVBoxLayout(grp)
        self.op = QComboBox()
        self.op.addItems(["Compress","Remove Metadata","Sanitise (Remove Hidden Code)",
                          "Flatten","Protect with password","Rotate 90°"])
        gl.addWidget(self.op)
        self.body.addWidget(grp)

        go = QPushButton("⚡  Run Batch"); go.setObjectName("action_btn")
        go.clicked.connect(self.run); self.body.addWidget(go)

    def add_files(self, files):
        for f in files:
            if not any(self.file_list.item(i).text()==f
                       for i in range(self.file_list.count())):
                self.file_list.addItem(f)

    def remove_sel(self):
        for item in self.file_list.selectedItems():
            self.file_list.takeItem(self.file_list.row(item))

    def run(self):
        files = [self.file_list.item(i).text() for i in range(self.file_list.count())]
        if not files: return self.msg("Add files first.", "warn")
        out_dir = QFileDialog.getExistingDirectory(self, "Select Output Folder")
        if not out_dir: return
        op = self.op.currentIndex()
        pw = ""
        if op == 4:
            pw, ok = QInputDialog.getText(self, "Password", "Enter password:",
                                          QLineEdit.EchoMode.Password)
            if not ok: return
        self.run_worker(_batch_process, files, out_dir, op, pw)

def _batch_process(files, out_dir, op, pw, progress_cb, status_cb):
    import fitz
    done = 0
    for i, f in enumerate(files):
        base = Path(f).stem
        suffix_map = ["_compressed","_clean_meta","_sanitised","_flat","_protected","_rotated"]
        out = os.path.join(out_dir, base + suffix_map[op] + ".pdf")
        status_cb(f"Processing {Path(f).name}...")
        try:
            if op == 0:   _compress_pdf(f, out, 1, lambda x:None, lambda x:None)
            elif op == 1: _remove_metadata(f, out, "", "", lambda x:None, lambda x:None)
            elif op == 2: _sanitise_pdf(f, out, True,True,True,True,True,True,
                                        lambda x:None, lambda x:None)
            elif op == 3: _flatten_pdf(f, out, lambda x:None, lambda x:None)
            elif op == 4: _protect_pdf(f, out, pw, pw, False,False,False,
                                       lambda x:None, lambda x:None)
            elif op == 5: _rotate_pdf(f, out, 90, "", lambda x:None, lambda x:None)
            done += 1
            status_cb(f"  ✔ {Path(f).name}")
        except Exception as e:
            status_cb(f"  ✘ {Path(f).name}: {e}")
        progress_cb(int((i+1)/len(files)*100))
    return f"Batch complete: {done}/{len(files)} files processed → {out_dir}"

# ═══════════════════════════════════════════════════════════════════════════════
#  DASHBOARD / HOME
# ═══════════════════════════════════════════════════════════════════════════════

TOOLS = [
    # (id, icon, name, desc, badge, category)
    ("merge",       "📑","Merge",            "Combine multiple PDFs",         "","organise"),
    ("split",       "✂️","Split",             "Split into pages / ranges",     "","organise"),
    ("compress",    "🗜️","Compress",          "Reduce file size",              "","optimise"),
    ("extract",     "📑","Extract Pages",     "Save specific pages",           "","organise"),
    ("delete",      "🗑️","Delete Pages",      "Remove unwanted pages",         "","organise"),
    ("rotate",      "🔃","Rotate Pages",      "Rotate page orientation",       "","organise"),
    ("crop",        "✂️","Crop",              "Trim page margins",             "","edit"),
    ("number",      "🔢","Number Pages",      "Add page numbers",              "","edit"),
    ("annotate",    "✍️","Annotate",          "Add notes & highlights",        "","edit"),
    ("flatten",     "📥","Flatten",           "Merge form fields into page",   "","edit"),
    ("word",        "📝","PDF ↔ Word",        "Convert to/from .docx",         "","convert"),
    ("excel",       "📊","PDF ↔ Excel",       "Extract tables to .xlsx",       "","convert"),
    ("pptx",        "📊","PDF ↔ PowerPoint",  "Convert to .pptx slides",       "","convert"),
    ("image",       "🖼️","PDF ↔ Image",       "Convert to/from PNG/JPG",       "","convert"),
    ("ocr",         "🔍","PDF OCR",           "Make scanned PDFs searchable",  "","convert"),
    ("translate",   "🌐","Translate",         "Translate PDF text",            "","convert"),
    ("protect",     "🔒","Protect",           "Add password encryption",       "","security"),
    ("unlock",      "🔓","Unlock",            "Remove PDF password",           "","security"),
    ("sign",        "✒️","Sign",              "Add text signature",            "","security"),
    ("redact",      "⬛","Redact",            "Black out sensitive text",      "","security"),
    ("watermark",   "💧","Add Watermark",     "Stamp text watermark",          "","edit"),
    ("rm_watermark","🪄","Remove Watermark",  "Strip text & image watermarks", "New","security"),
    ("sanitise",    "🛡️","Remove Hidden Code","Strip JS, scripts & threats",   "🔐","security"),
    ("metadata",    "🧹","Remove Metadata",   "Strip author, dates & XMP",     "🔐","security"),
    ("summarise",   "📋","Summarise",         "Extract & read PDF text",       "","view"),
    ("batch",       "⚡","Batch Process",     "Apply operation to many PDFs",  "","tools"),
]

class DashboardPage(QWidget):
    tool_selected = pyqtSignal(str)

    def __init__(self, p=None):
        super().__init__(p)
        root = QVBoxLayout(self)
        root.setContentsMargins(24, 20, 24, 20)
        root.setSpacing(0)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        inner = QWidget(); inner.setObjectName("content_area")
        lay = QVBoxLayout(inner); lay.setSpacing(16); lay.setContentsMargins(0,0,12,0)

        cats = [("Most Used", ["merge","split","compress","word","image","sanitise","metadata"]),
                ("Convert",   ["word","excel","pptx","image","ocr","translate"]),
                ("Edit & Organise", ["extract","delete","rotate","crop","number","annotate","flatten"]),
                ("Security",  ["protect","unlock","sign","redact","rm_watermark","sanitise","metadata"]),
                ("Optimise & View", ["compress","summarise","batch"])]

        seen_in_sections = set()
        for cat_name, ids in cats:
            lbl = QLabel(cat_name.upper())
            lbl.setObjectName("section_title")
            lbl.setContentsMargins(0, 8, 0, 4)
            lay.addWidget(lbl)
            grid_widget = QWidget()
            grid = QGridLayout(grid_widget)
            grid.setSpacing(8)
            grid.setContentsMargins(0,0,0,0)
            col = 0; row = 0
            for tid in ids:
                t = next((x for x in TOOLS if x[0]==tid), None)
                if not t: continue
                card = ToolCard(t[0], t[1], t[2], t[3], t[4])
                card.clicked.connect(self.tool_selected.emit)
                grid.addWidget(card, row, col)
                col += 1
                if col >= 3: col = 0; row += 1
                seen_in_sections.add(tid)
            lay.addWidget(grid_widget)

        scroll.setWidget(inner)
        root.addWidget(scroll)

# ═══════════════════════════════════════════════════════════════════════════════
#  MAIN WINDOW
# ═══════════════════════════════════════════════════════════════════════════════

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("PDFForge Pro")
        self.setMinimumSize(1100, 720)
        self.dark_mode = False
        self._build()
        self.apply_theme()

    def _build(self):
        central = QWidget(); central.setObjectName("central")
        self.setCentralWidget(central)
        main_lay = QHBoxLayout(central); main_lay.setContentsMargins(0,0,0,0); main_lay.setSpacing(0)

        # ── Sidebar ──────────────────────────────────────────────────────────
        self.sidebar = QWidget(); self.sidebar.setObjectName("sidebar")
        self.sidebar.setFixedWidth(210)
        sb_lay = QVBoxLayout(self.sidebar); sb_lay.setContentsMargins(0,0,0,0); sb_lay.setSpacing(0)

        # Logo
        logo_widget = QWidget(); logo_widget.setFixedHeight(60)
        logo_lay = QHBoxLayout(logo_widget); logo_lay.setContentsMargins(16,0,16,0)
        logo_lbl = QLabel("🗂️  PDFForge Pro"); logo_lbl.setObjectName("app_title")
        logo_lay.addWidget(logo_lbl)
        sb_lay.addWidget(logo_widget)

        # Nav scroll
        nav_scroll = QScrollArea(); nav_scroll.setWidgetResizable(True)
        nav_scroll.setFrameShape(QFrame.Shape.NoFrame)
        nav_inner = QWidget(); nav_lay = QVBoxLayout(nav_inner)
        nav_lay.setContentsMargins(8,8,8,8); nav_lay.setSpacing(2)

        self.nav_buttons = {}

        def add_section(label):
            lbl = QLabel(label); lbl.setObjectName("nav_section_label")
            lbl.setContentsMargins(8,10,0,2)
            nav_lay.addWidget(lbl)

        def add_nav(tool_id, icon, label):
            btn = QPushButton(f"  {icon}  {label}")
            btn.setObjectName("nav_btn")
            btn.setFixedHeight(36)
            btn.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
            btn.clicked.connect(lambda: self.show_tool(tool_id))
            nav_lay.addWidget(btn)
            self.nav_buttons[tool_id] = btn

        add_nav("home","🏠","Dashboard")
        add_section("CONVERT")
        for tid in ["word","excel","pptx","image","ocr","translate"]:
            t = next(x for x in TOOLS if x[0]==tid)
            add_nav(tid, t[1], t[2])
        add_section("ORGANISE")
        for tid in ["merge","split","extract","delete","rotate","crop","number"]:
            t = next(x for x in TOOLS if x[0]==tid)
            add_nav(tid, t[1], t[2])
        add_section("EDIT")
        for tid in ["annotate","flatten","watermark","compress"]:
            t = next(x for x in TOOLS if x[0]==tid)
            add_nav(tid, t[1], t[2])
        add_section("SECURITY")
        for tid in ["protect","unlock","sign","redact","rm_watermark"]:
            t = next(x for x in TOOLS if x[0]==tid)
            add_nav(tid, t[1], t[2])
        add_section("SAFETY 🛡️")
        for tid in ["sanitise","metadata"]:
            t = next(x for x in TOOLS if x[0]==tid)
            add_nav(tid, t[1], t[2])
        add_section("TOOLS")
        for tid in ["summarise","batch"]:
            t = next(x for x in TOOLS if x[0]==tid)
            add_nav(tid, t[1], t[2])

        nav_lay.addStretch()
        nav_scroll.setWidget(nav_inner)
        sb_lay.addWidget(nav_scroll)

        # Theme toggle
        theme_btn = QPushButton("🌙  Dark Mode")
        theme_btn.setObjectName("secondary_btn")
        theme_btn.setFixedHeight(36)
        theme_btn.setContentsMargins(8,4,8,4)
        theme_btn.clicked.connect(self.toggle_theme)
        self.theme_btn = theme_btn
        sb_lay.addWidget(theme_btn)

        main_lay.addWidget(self.sidebar)

        # ── Right area ───────────────────────────────────────────────────────
        right = QWidget(); right.setObjectName("central")
        right_lay = QVBoxLayout(right); right_lay.setContentsMargins(0,0,0,0); right_lay.setSpacing(0)

        # Topbar
        self.topbar = QWidget(); self.topbar.setObjectName("topbar"); self.topbar.setFixedHeight(56)
        tb_lay = QHBoxLayout(self.topbar); tb_lay.setContentsMargins(24,0,24,0)
        self.topbar_title = QLabel("Dashboard"); self.topbar_title.setObjectName("page_title")
        self.topbar_sub   = QLabel("26 PDF tools"); self.topbar_sub.setObjectName("page_subtitle")
        tb_left = QVBoxLayout(); tb_left.setSpacing(0)
        tb_left.addWidget(self.topbar_title); tb_left.addWidget(self.topbar_sub)
        open_btn = QPushButton("+ Open PDF"); open_btn.setObjectName("open_btn")
        open_btn.clicked.connect(self.quick_open)
        tb_lay.addLayout(tb_left); tb_lay.addStretch(); tb_lay.addWidget(open_btn)
        right_lay.addWidget(self.topbar)

        # Stack
        self.stack = QStackedWidget()
        right_lay.addWidget(self.stack)

        # Status bar
        self.status_widget = QWidget(); self.status_widget.setObjectName("statusbar_widget")
        self.status_widget.setFixedHeight(28)
        st_lay = QHBoxLayout(self.status_widget); st_lay.setContentsMargins(20,0,20,0)
        self.status_lbl = QLabel("Ready"); self.status_lbl.setObjectName("status_text")
        st_lay.addWidget(self.status_lbl); st_lay.addStretch()
        right_lay.addWidget(self.status_widget)

        main_lay.addWidget(right)

        # ── Build pages ──────────────────────────────────────────────────────
        self.pages = {}
        dash = DashboardPage()
        dash.tool_selected.connect(self.show_tool)
        self.stack.addWidget(dash)
        self.pages["home"] = dash

        page_classes = {
            "merge": MergePage, "split": SplitPage, "compress": CompressPage,
            "word": WordPage, "excel": ExcelPage, "pptx": PowerPointPage,
            "image": ImagePage, "rotate": RotatePage, "extract": ExtractPage,
            "delete": DeletePagesPage, "ocr": OCRPage, "protect": ProtectPage,
            "unlock": UnlockPage, "watermark": WatermarkPage,
            "rm_watermark": RemoveWatermarkPage, "redact": RedactPage,
            "sign": SignPage, "number": NumberPagesPage, "crop": CropPage,
            "flatten": FlattenPage, "annotate": AnnotatePage,
            "summarise": SummarisePage, "sanitise": SanitisePage,
            "metadata": MetadataPage, "translate": TranslatePage,
            "batch": BatchPage,
        }
        for tid, cls in page_classes.items():
            w = QScrollArea()
            w.setWidgetResizable(True)
            w.setFrameShape(QFrame.Shape.NoFrame)
            page = cls()
            page.status_update.connect(self.set_status)
            w.setWidget(page)
            self.stack.addWidget(w)
            self.pages[tid] = w

        self.show_tool("home")

    def show_tool(self, tool_id):
        if tool_id not in self.pages: return
        for tid, btn in self.nav_buttons.items():
            btn.setProperty("active", tid == tool_id)
            btn.style().unpolish(btn); btn.style().polish(btn)
        self.stack.setCurrentWidget(self.pages[tool_id])
        t = next((x for x in TOOLS if x[0]==tool_id), None)
        if tool_id == "home":
            self.topbar_title.setText("Dashboard")
            self.topbar_sub.setText("26 PDF tools available")
        elif t:
            self.topbar_title.setText(t[2])
            self.topbar_sub.setText(t[3])

    def quick_open(self):
        f, _ = QFileDialog.getOpenFileName(self,"Open PDF","","PDF Files (*.pdf)")
        if f:
            self.set_status(f"Opened: {Path(f).name}")

    def set_status(self, msg):
        self.status_lbl.setText(msg)
        QTimer.singleShot(6000, lambda: self.status_lbl.setText("Ready"))

    def toggle_theme(self):
        self.dark_mode = not self.dark_mode
        self.theme_btn.setText("☀️  Light Mode" if self.dark_mode else "🌙  Dark Mode")
        self.apply_theme()

    def apply_theme(self):
        self.setStyleSheet(DARK_THEME if self.dark_mode else LIGHT_THEME)

# ── Entry point ───────────────────────────────────────────────────────────────

def main():
    app = QApplication(sys.argv)
    app.setApplicationName("PDFForge Pro")
    app.setOrganizationName("PDFForge")
    try:
        font = QFont("Segoe UI", 10)
        app.setFont(font)
    except Exception:
        pass
    win = MainWindow()
    win.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
