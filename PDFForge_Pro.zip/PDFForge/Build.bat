@echo off
echo.
echo ################################################
echo #                                              #
echo #          PDFForge Pro  -  BUILD              #
echo #     Run this ONCE to install everything      #
echo #                                              #
echo ################################################
echo.
echo This will download and install all required packages.
echo Make sure you have an internet connection.
echo.
pause

:: ── Check Python ─────────────────────────────────────────────────────────────
echo [1/3] Checking Python...
python --version >nul 2>&1
if errorlevel 1 (
    echo.
    echo  [ERROR] Python not found!
    echo.
    echo  Please install Python 3.10 or newer:
    echo  https://www.python.org/downloads/
    echo.
    echo  IMPORTANT: During install tick the checkbox:
    echo     "Add Python to PATH"
    echo.
    pause
    exit /b 1
)
python --version
echo  [OK] Python found.
echo.

:: ── Upgrade pip ──────────────────────────────────────────────────────────────
echo [2/3] Upgrading pip...
python -m pip install --upgrade pip --quiet
echo  [OK] pip upgraded.
echo.

:: ── Install all packages ─────────────────────────────────────────────────────
echo [3/3] Installing packages (this may take 3-5 minutes)...
echo.

echo  Installing PyQt6 (the UI framework)...
python -m pip install PyQt6 --quiet
if errorlevel 1 ( echo  [WARN] PyQt6 had issues, retrying... & python -m pip install PyQt6 )

echo  Installing PyMuPDF (core PDF engine)...
python -m pip install pymupdf --quiet
if errorlevel 1 ( echo  [WARN] PyMuPDF had issues, retrying... & python -m pip install pymupdf )

echo  Installing pypdf...
python -m pip install pypdf --quiet

echo  Installing Pillow (image processing)...
python -m pip install Pillow --quiet

echo  Installing python-docx (Word support)...
python -m pip install python-docx --quiet

echo  Installing python-pptx (PowerPoint support)...
python -m pip install python-pptx --quiet

echo  Installing pdfplumber (table extraction)...
python -m pip install pdfplumber --quiet

echo  Installing openpyxl (Excel support)...
python -m pip install openpyxl --quiet

echo  Installing reportlab (PDF creation)...
python -m pip install reportlab --quiet

echo  Installing deep-translator (translation - needs internet when used)...
python -m pip install deep-translator --quiet

:: ── Verify critical packages ─────────────────────────────────────────────────
echo.
echo  Verifying installation...
python -c "import PyQt6; print('  [OK] PyQt6')"         2>nul || echo  [FAIL] PyQt6 — try running as Administrator
python -c "import fitz;  print('  [OK] PyMuPDF')"        2>nul || echo  [FAIL] PyMuPDF — run: python -m pip install pymupdf
python -c "import pypdf; print('  [OK] pypdf')"          2>nul || echo  [FAIL] pypdf
python -c "import PIL;   print('  [OK] Pillow')"         2>nul || echo  [FAIL] Pillow
python -c "import docx;  print('  [OK] python-docx')"    2>nul || echo  [FAIL] python-docx
python -c "import pptx;  print('  [OK] python-pptx')"    2>nul || echo  [FAIL] python-pptx
python -c "import pdfplumber; print('  [OK] pdfplumber')" 2>nul || echo  [FAIL] pdfplumber
python -c "import openpyxl;   print('  [OK] openpyxl')"  2>nul || echo  [FAIL] openpyxl
python -c "import reportlab;  print('  [OK] reportlab')" 2>nul || echo  [FAIL] reportlab

:: ── Write the ready flag ──────────────────────────────────────────────────────
echo PDFFORGE_BUILT=1 > .build_complete
echo BUILD_DATE=%date% %time% >> .build_complete

echo.
echo ################################################
echo #                                              #
echo #   Build complete! All packages installed.   #
echo #                                              #
echo #   Now use  Run.bat  to launch the app.      #
echo #   You do NOT need internet after this.      #
echo #                                              #
echo ################################################
echo.
pause
