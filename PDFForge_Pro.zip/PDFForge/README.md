# PDFForge Pro 🗂️

A full-featured, offline Windows PDF tool suite — 26 tools in one app.

---

## ✅ Quick Start (Windows)

1. Make sure **Python 3.10+** is installed → https://python.org  
   *(During install, tick ✅ "Add Python to PATH")*

2. Double-click **`Launch_PDFForge.bat`**  
   It will install all packages automatically and launch the app.

That's it!

---

## 📦 Manual Install (if the .bat doesn't work)

Open Command Prompt in this folder and run:

```
pip install -r requirements.txt
python main.py
```

---

## 🛠️ All 26 Tools

### Convert
| Tool | What it does |
|------|-------------|
| PDF ↔ Word | Extract text from PDF into .docx; convert .docx → PDF (needs LibreOffice) |
| PDF ↔ Excel | Extract tables from PDF into .xlsx |
| PDF ↔ PowerPoint | Convert PDF pages into .pptx slides |
| PDF ↔ Image | Render PDF pages as PNG/JPG/TIFF; combine images into PDF |
| PDF OCR | Make scanned PDFs text-searchable (needs Tesseract) |
| Translate | Translate PDF text to 14+ languages (needs internet) |

### Organise
| Tool | What it does |
|------|-------------|
| Merge | Combine multiple PDFs into one (drag to reorder) |
| Split | Split into individual pages or custom ranges |
| Extract Pages | Save specific pages as a new PDF |
| Delete Pages | Remove unwanted pages |
| Rotate | Rotate all or specific pages |
| Crop | Trim page margins |
| Number Pages | Add page numbers (multiple formats & positions) |

### Edit
| Tool | What it does |
|------|-------------|
| Annotate | Add coloured text notes to any page |
| Flatten | Merge form fields & annotations permanently |
| Add Watermark | Stamp diagonal text watermark |
| Compress | Reduce file size (3 quality levels) |

### Security
| Tool | What it does |
|------|-------------|
| Protect | Add password (user + owner) with permission controls |
| Unlock | Remove password from encrypted PDF |
| Sign | Add text signature with date |
| Redact | Permanently black out sensitive text (search-based) |
| Remove Watermark | Strip text & image watermarks |

### 🛡️ Safety (unique features)
| Tool | What it does |
|------|-------------|
| **Remove Hidden Code** | Strips JavaScript, Launch actions, URI actions, embedded files, OpenAction, Named actions — all potential attack vectors in PDFs downloaded from the internet |
| **Remove Metadata** | Strips author name, company, software, creation date, modification date, XMP metadata, GPS data — anything that identifies you or the document's origin |

### Tools
| Tool | What it does |
|------|-------------|
| Summarise | Extract and display all text from PDF |
| Batch Process | Apply Compress / Remove Metadata / Sanitise / Flatten / Protect / Rotate to many files at once |

---

## 🔧 Optional External Tools

| Feature | Requires | Download |
|---------|----------|----------|
| OCR | Tesseract | https://github.com/UB-Mannheim/tesseract/wiki |
| Word → PDF | LibreOffice | https://libreoffice.org |
| Translate | Internet connection | (uses Google Translate free API) |

---

## 🔒 Privacy

All processing is done **100% offline and locally** on your machine.  
No files are uploaded anywhere. No data is sent to any server (except Translate, which uses Google Translate).

---

## 💡 Tips

- **Drag & Drop** — drag PDF files directly onto any drop zone
- **Batch Process** — use it to sanitise and remove metadata from many downloaded PDFs at once
- **Dark Mode** — click the toggle in the bottom-left sidebar
- **Safety Workflow** — for any PDF downloaded online, run "Remove Hidden Code" then "Remove Metadata" before opening fully
