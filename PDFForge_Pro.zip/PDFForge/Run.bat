@echo off
echo.
echo ################################################
echo #                                              #
echo #          PDFForge Pro  -  LAUNCH             #
echo #                                              #
echo ################################################
echo.

:: ── Check if Build.bat was run first ─────────────────────────────────────────
if not exist ".build_complete" (
    echo  [ERROR] App has not been set up yet!
    echo.
    echo  Please run  Build.bat  first to install
    echo  all required packages. You only need to
    echo  do this once.
    echo.
    echo  After Build.bat finishes, use Run.bat
    echo  every time to launch instantly.
    echo.
    pause
    exit /b 1
)

:: ── Check Python ─────────────────────────────────────────────────────────────
python --version >nul 2>&1
if errorlevel 1 (
    echo  [ERROR] Python not found on PATH.
    echo  Make sure Python is installed and "Add to PATH" was ticked.
    pause
    exit /b 1
)

:: ── Quick package check (no downloading) ─────────────────────────────────────
python -c "import PyQt6, fitz, pypdf, PIL, docx, pptx, pdfplumber, openpyxl, reportlab" >nul 2>&1
if errorlevel 1 (
    echo  [WARN] One or more packages seem missing.
    echo  Running Build.bat is recommended to repair.
    echo.
    echo  Attempting to launch anyway...
    echo.
)

:: ── Launch ────────────────────────────────────────────────────────────────────
echo  Starting PDFForge Pro...
echo.
python main.py

if errorlevel 1 (
    echo.
    echo  [ERROR] The application crashed.
    echo.
    echo  Common fixes:
    echo    1. Run Build.bat again to repair packages
    echo    2. Make sure you are in the PDFForge folder
    echo    3. Try running as Administrator
    echo.
    pause
)
